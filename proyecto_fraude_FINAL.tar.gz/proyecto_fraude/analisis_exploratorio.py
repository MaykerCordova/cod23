"""
Script de análisis exploratorio post-ETL.
Ejemplos de queries comunes sobre la tabla consolidada.
"""
import polars as pl
from pathlib import Path

from config.paths import MASTER_DB, MASTER_TABLE
from src.loaders.sqlite_loader import SQLiteLoader


def analisis_basico():
    """Análisis básico de la tabla consolidada."""
    
    print("\n" + "=" * 80)
    print("ANÁLISIS EXPLORATORIO - TABLA MASTER CONSOLIDADA")
    print("=" * 80)
    
    with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
        
        # 1. TOTAL DE REGISTROS
        total = loader.get_row_count()
        print(f"\n📊 Total de registros: {total:,}")
        
        # 2. DISTRIBUCIÓN POR HERRAMIENTA
        print("\n" + "-" * 60)
        print("DISTRIBUCIÓN POR HERRAMIENTA")
        print("-" * 60)
        
        df_dist = loader.query(f"""
            SELECT 
                herramienta,
                COUNT(*) as cantidad,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM {MASTER_TABLE}), 2) as porcentaje,
                MIN(fecha) as fecha_min,
                MAX(fecha) as fecha_max
            FROM {MASTER_TABLE}
            GROUP BY herramienta
            ORDER BY cantidad DESC
        """)
        print(df_dist)
        
        # 3. TOP 10 COMERCIOS POR VOLUMEN
        print("\n" + "-" * 60)
        print("TOP 10 COMERCIOS POR CANTIDAD DE TRANSACCIONES")
        print("-" * 60)
        
        df_top_comercios = loader.query(f"""
            SELECT 
                nombre_comercio,
                COUNT(*) as transacciones,
                ROUND(SUM(monto_usd), 2) as monto_total_usd,
                ROUND(AVG(monto_usd), 2) as monto_promedio
            FROM {MASTER_TABLE}
            WHERE nombre_comercio IS NOT NULL
            GROUP BY nombre_comercio
            ORDER BY transacciones DESC
            LIMIT 10
        """)
        print(df_top_comercios)
        
        # 4. EVOLUCIÓN MENSUAL
        print("\n" + "-" * 60)
        print("EVOLUCIÓN MENSUAL (ÚLTIMOS 6 MESES)")
        print("-" * 60)
        
        df_mensual = loader.query(f"""
            SELECT 
                strftime('%Y-%m', fecha) as mes,
                COUNT(*) as transacciones,
                ROUND(SUM(monto_usd), 2) as monto_total
            FROM {MASTER_TABLE}
            WHERE fecha >= date('now', '-6 months')
            GROUP BY mes
            ORDER BY mes DESC
        """)
        print(df_mensual)
        
        # 5. CALIDAD DE DATOS (NA%)
        print("\n" + "-" * 60)
        print("CALIDAD DE DATOS - % NULOS POR COLUMNA")
        print("-" * 60)
        
        # Leer muestra para calcular NA%
        df_sample = loader.query(f"SELECT * FROM {MASTER_TABLE} LIMIT 10000")
        
        na_pct = (
            df_sample
            .select([
                (pl.col(c).is_null().sum() / len(df_sample) * 100).alias(c)
                for c in df_sample.columns
            ])
            .transpose(include_header=True, header_name="columna", column_names=["na_pct"])
            .sort("na_pct", descending=True)
        )
        print(na_pct)
        
        # 6. ENTRY MODES MÁS COMUNES
        print("\n" + "-" * 60)
        print("ENTRY MODES MÁS FRECUENTES")
        print("-" * 60)
        
        df_entry = loader.query(f"""
            SELECT 
                entry_mode,
                COUNT(*) as cantidad,
                ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM {MASTER_TABLE}), 2) as porcentaje
            FROM {MASTER_TABLE}
            WHERE entry_mode IS NOT NULL
            GROUP BY entry_mode
            ORDER BY cantidad DESC
            LIMIT 10
        """)
        print(df_entry)
        
        # 7. PAÍSES CON MAYOR ACTIVIDAD
        print("\n" + "-" * 60)
        print("TOP 10 PAÍSES POR VOLUMEN TRANSACCIONAL")
        print("-" * 60)
        
        df_paises = loader.query(f"""
            SELECT 
                codigo_pais,
                COUNT(*) as transacciones,
                ROUND(SUM(monto_usd), 2) as monto_total
            FROM {MASTER_TABLE}
            WHERE codigo_pais IS NOT NULL
            GROUP BY codigo_pais
            ORDER BY transacciones DESC
            LIMIT 10
        """)
        print(df_paises)


def analisis_fraude():
    """Análisis específico de fraude (si existe columna concresultado_vcas)."""
    
    print("\n" + "=" * 80)
    print("ANÁLISIS DE FRAUDE - VCAS")
    print("=" * 80)
    
    with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
        
        # Verificar si hay datos VCAS
        df_vcas_count = loader.query(f"""
            SELECT COUNT(*) as cant
            FROM {MASTER_TABLE}
            WHERE herramienta = 'VCAS'
        """)
        
        if df_vcas_count["cant"][0] == 0:
            print("\n⚠️  No hay registros VCAS en la base")
            return
        
        # Distribución de resultados VCAS
        print("\n" + "-" * 60)
        print("DISTRIBUCIÓN DE RESULTADOS VCAS")
        print("-" * 60)
        
        df_resultados = loader.query(f"""
            SELECT 
                concresultado_vcas,
                COUNT(*) as cantidad,
                ROUND(SUM(monto_usd), 2) as monto_total,
                ROUND(AVG(monto_usd), 2) as monto_promedio
            FROM {MASTER_TABLE}
            WHERE herramienta = 'VCAS' 
              AND concresultado_vcas IS NOT NULL
            GROUP BY concresultado_vcas
            ORDER BY cantidad DESC
        """)
        print(df_resultados)


def exportar_para_powerbi():
    """Exporta vistas agregadas para Power BI."""
    
    print("\n" + "=" * 80)
    print("EXPORTANDO VISTAS AGREGADAS PARA POWER BI")
    print("=" * 80)
    
    output_dir = Path("data/processed/powerbi_views")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
        
        # Vista 1: Resumen diario por herramienta
        df_diario = loader.query(f"""
            SELECT 
                fecha,
                herramienta,
                COUNT(*) as cant_transacciones,
                SUM(monto_usd) as monto_total,
                AVG(monto_usd) as monto_promedio,
                COUNT(DISTINCT nombre_comercio) as comercios_unicos
            FROM {MASTER_TABLE}
            GROUP BY fecha, herramienta
            ORDER BY fecha DESC, herramienta
        """)
        
        parquet_diario = output_dir / "resumen_diario_herramienta.parquet"
        df_diario.write_parquet(parquet_diario)
        print(f"✓ {parquet_diario}")
        
        # Vista 2: Ranking de comercios
        df_comercios = loader.query(f"""
            SELECT 
                nombre_comercio,
                codigo_pais,
                COUNT(*) as total_transacciones,
                SUM(monto_usd) as monto_total,
                AVG(monto_usd) as ticket_promedio,
                MIN(fecha) as primera_transaccion,
                MAX(fecha) as ultima_transaccion
            FROM {MASTER_TABLE}
            WHERE nombre_comercio IS NOT NULL
            GROUP BY nombre_comercio, codigo_pais
            HAVING total_transacciones >= 10
            ORDER BY total_transacciones DESC
        """)
        
        parquet_comercios = output_dir / "ranking_comercios.parquet"
        df_comercios.write_parquet(parquet_comercios)
        print(f"✓ {parquet_comercios}")
        
        print(f"\n📂 Archivos Parquet guardados en: {output_dir}")
        print("   Importar estos archivos en Power BI para mejor performance")


if __name__ == "__main__":
    analisis_basico()
    analisis_fraude()
    
    # Opcional: exportar para Power BI
    # exportar_para_powerbi()
