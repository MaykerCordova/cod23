"""
Esquemas de datos y definiciones del dominio.
Define tipos de datos explícitos para cada columna master.
"""
import polars as pl

# ============================================================================
# ESQUEMA MASTER (columnas finales consolidadas)
# ============================================================================
MASTER_SCHEMA = {
    "fecha": pl.Date,
    "monto_usd": pl.Float64,
    "bin": pl.Utf8,
    "nombre_comercio": pl.Utf8,
    "entry_mode": pl.Utf8,
    "codigo_pais": pl.Utf8,
    "concresultado_vcas": pl.Utf8,
    "herramienta": pl.Utf8,
    # Columnas de control interno
    "fecha_carga": pl.Datetime,
    "hash_id": pl.Utf8  # Para deduplicación
}

# Columnas obligatorias (para validación)
REQUIRED_COLS = ["fecha", "monto_usd", "herramienta"]

# ============================================================================
# MAPEO DE SINÓNIMOS (normalizado)
# ============================================================================
# Cada campo master tiene una lista de posibles nombres en las fuentes
COLUMN_SYNONYMS = {
    "fecha": [
        "fecha",
        "acf-fecha trx",
        "acf-fecha",
        "rt-fecha trx"
    ],
    
    "monto_usd": [
        "monto usd",
        "monto",
        "acf-monto unico",
        "acf-monto dollar",
        "rt-monto trx"
    ],
    
    "bin": [
        "bin",
        "acf-bin"
    ],
    
    "nombre_comercio": [
        "nombre de comercio",
        "comercio",
        "acf-nombre comercio",
        "acf-nombre/localizacion comercio",
        "merchant country",
        "rt-nombre comercio"
    ],
    
    "entry_mode": [
        "entry mode",
        "acf-entry mode"
    ],
    
    "codigo_pais": [
        "codigo pais",
        "merchant country",
        "acf-pais origen 87519",
        "de61.13 pais del pos",
        # Casos especiales FRM (se busca por substring)
        "pais del pos"
    ],
    
    "concresultado_vcas": [
        "reglas concaresultado",
        "concaresultado vcas",
        "reglas concaresultado"
    ]
}

# ============================================================================
# FILTROS POR HERRAMIENTA (lógica de negocio)
# ============================================================================
FILTROS_HERRAMIENTAS = {
    "FRM": {
        "excluir_condicion": ["NM", "RD"],
        "solo_de39": "63"
    },
    
    "RT_CREDITO": {
        "fecha_minima": "2025-06-01"  # Solo registros desde esta fecha
    }
}

# ============================================================================
# COMPOSITE KEY PARA DEDUPLICACIÓN
# ============================================================================
# Columnas que, juntas, identifican un registro único
DEDUP_KEY_COLS = ["fecha", "monto_usd", "bin", "nombre_comercio", "herramienta"]
