"""
Configuración centralizada de rutas del proyecto.
Facilita mantenimiento y evita hardcoding disperso.
"""
from pathlib import Path

# ============================================================================
# RUTAS BASE
# ============================================================================
PROJECT_ROOT = Path(__file__).parent.parent
DATA_DIR = PROJECT_ROOT / "data"
LOGS_DIR = PROJECT_ROOT / "logs"

# ============================================================================
# FUENTES ACCESS
# ============================================================================
# TODO: Ajustar estas rutas según tu entorno
ACCESS_BASE = Path(r"C:\Users\s4930359\The Bank of Nova Scotia\Flores Hilario, Marcial - BBDD")

RUTA_BD_VRM = ACCESS_BASE / "BBDD_VRM.accdb"
RUTA_BD_FRM = ACCESS_BASE / "BBDD_FRM.accdb"
RUTA_BD_RT_D = ACCESS_BASE / "BBDD_Real_Time.accdb"
RUTA_BD_RT_C = ACCESS_BASE / "BBDD_Real_Time_TC_UBA.accdb"

TABLA_VRM = "BBDD_VRM"
TABLA_FRM = "BBDD_FRM"
TABLA_RT_D = "BBDD_REAL_TIME_TD"
TABLA_RT_C = "BBDD_Real_Time_TC_UBA"

# ============================================================================
# FUENTES CSV
# ============================================================================
VCAS_CSV = ACCESS_BASE / "VCAS" / "VCAS_CONSOLIDADO_sin_dedup.csv"

# ============================================================================
# OUTPUTS
# ============================================================================
PROCESSED_DIR = DATA_DIR / "processed"
DIAGNOSTICS_DIR = DATA_DIR / "diagnosticos"
HISTORICO_DIR = DATA_DIR / "historico"

# SQLite
MASTER_DB = HISTORICO_DIR / "master.db"
MASTER_TABLE = "master_consolidado"

# Parquets intermedios (por herramienta)
PARQUET_VRM = PROCESSED_DIR / "vrm_staging.parquet"
PARQUET_FRM = PROCESSED_DIR / "frm_staging.parquet"
PARQUET_RT_D = PROCESSED_DIR / "rt_debito_staging.parquet"
PARQUET_RT_C = PROCESSED_DIR / "rt_credito_staging.parquet"
PARQUET_VCAS = PROCESSED_DIR / "vcas_staging.parquet"

# Control de carga incremental
LAST_UPDATE_JSON = HISTORICO_DIR / "last_update.json"

# Reportes de diagnóstico
REPORT_MAPPING = DIAGNOSTICS_DIR / "mapping_usado.csv"
REPORT_NA = DIAGNOSTICS_DIR / "na_por_herramienta.csv"
REPORT_PARSE_FAILS = DIAGNOSTICS_DIR / "parse_fallos.csv"
REPORT_DUPLICADOS = DIAGNOSTICS_DIR / "duplicados_detectados.csv"

# ============================================================================
# INICIALIZACIÓN
# ============================================================================
def ensure_directories():
    """Crea directorios necesarios si no existen."""
    for directory in [
        DATA_DIR,
        PROCESSED_DIR,
        DIAGNOSTICS_DIR,
        HISTORICO_DIR,
        LOGS_DIR
    ]:
        directory.mkdir(parents=True, exist_ok=True)
