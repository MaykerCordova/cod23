# ❓ Preguntas Frecuentes (FAQ)

## 🔍 General

### ¿Qué problema resuelve este proyecto?
Consolida datos de múltiples herramientas antifraude (VRM, FRM, RT, VCAS) en una única fuente de verdad, eliminando:
- Carga completa repetida (95% datos duplicados)
- Inconsistencias entre herramientas
- Tiempo excesivo de procesamiento (15 min → 30s incremental)
- Duplicados en Power BI

### ¿Por qué no seguir con el código actual?
El código actual funciona, pero no escala:
- Full load cada vez (lento y costoso)
- Código monolítico (difícil mantener)
- Sin histórico persistente (siempre reconstruye)
- Deduplicación manual en Power BI (lento)

---

## 🛠️ Instalación y Setup

### ¿Qué versión de Python necesito?
Python 3.10 o superior. Verifica con:
```bash
python --version
```

### ¿Funciona en Python 3.9?
Polars funciona, pero algunos type hints pueden fallar. Recomendamos 3.10+.

### ¿Necesito instalar SQLite aparte?
No, SQLite viene incluido con Python. Solo necesitas el ODBC driver si quieres conectar Power BI.

### Error: "Microsoft Access Driver not found"
Instala [Microsoft Access Database Engine 2016](https://www.microsoft.com/en-us/download/details.aspx?id=54920).
⚠️ **Importante**: Descarga la versión (32-bit o 64-bit) que coincida con tu Python, no con tu Windows.

Verifica versión de Python:
```bash
python -c "import struct; print(struct.calcsize('P') * 8)"
# 32 → Descargar Access Database Engine 32-bit
# 64 → Descargar Access Database Engine 64-bit
```

### ¿Puedo usar esto en Linux/Mac?
El código funciona, pero:
- ❌ No hay driver Access ODBC nativo para Linux/Mac
- ✅ Solución: Exporta Access a CSV/Parquet en Windows, procesa en Linux/Mac

---

## 🔧 Ejecución

### ¿Cuánto demora la primera ejecución?
Depende del volumen:
- 500K registros/herramienta (~2.5M total): ~3-5 min
- 1M registros/herramienta (~5M total): ~8-10 min

### ¿Y las ejecuciones siguientes (incremental)?
Si solo hay 1-2% datos nuevos:
- ~30 segundos - 1 minuto

### ¿Cómo sé si está funcionando?
Revisa el log en consola:
```
EXTRACT | VRM | filas= 487,253 | cols= 45
TRANSFORM | VRM | in= 487,253 | out= 485,102
```

O el archivo de log en `logs/pipeline_YYYYMMDD_HHMMSS.log`

### ¿Puedo ejecutar en paralelo múltiples herramientas?
No implementado actualmente. El pipeline procesa secuencialmente por diseño (más simple, menos bugs).

Si necesitas paralelismo:
1. Procesa cada herramienta en script separado
2. Consolida al final con `pl.concat()`

---

## 💾 Datos y Almacenamiento

### ¿Cuánto espacio ocupa el SQLite?
Regla aproximada:
- 1M registros ≈ 150-200 MB
- 10M registros ≈ 1.5-2 GB

Compara con Parquet (más compacto):
- 1M registros ≈ 50-80 MB

### ¿Cuál es el límite de SQLite?
Teórico: 281 TB
Práctico: ~10-50 GB (luego performance se degrada)

Para >10M registros, considera:
- Particionar por año
- Migrar a PostgreSQL/SQL Server
- Usar DuckDB (mejor para analytics que SQLite)

### ¿Puedo borrar los Parquets intermedios en `data/processed/`?
Sí, son opcionales. Se generan solo si llamas:
```python
df.write_parquet("data/processed/herramienta_staging.parquet")
```

Útiles para:
- Debugging (revisar datos intermedios)
- ML downstream (features engineering)
- Backup antes de cargar a SQLite

### ¿Cada cuánto debo hacer backup del SQLite?
Depende de criticidad:
- **Alta criticidad**: Diario (antes de cada ejecución)
- **Media**: Semanal
- **Baja**: Mensual

Automatiza con:
```bash
python utils_historico.py  # Opción 2: Crear backup
```

---

## 🔍 Deduplicación

### ¿Cómo funciona la deduplicación?
Genera un hash único por transacción:
```python
hash(fecha + monto + bin + comercio + herramienta)
```

Si dos registros tienen mismo hash → son el mismo evento.

### ¿Qué pasa si cambia solo el monto por redondeo?
Puede no detectarse como duplicado. Ejemplo:
- Registro 1: monto = 150.00000001
- Registro 2: monto = 150.00

Solución: Redondear antes de hash (ya implementado en `deduplicator.py`).

### ¿Se detectan duplicados entre herramientas?
Sí. Si la misma transacción aparece en VRM y VCAS, se detecta porque el hash incluye campos comunes (fecha, monto, bin).

### ¿Puedo cambiar los campos del hash?
Sí, edita `config/schemas.py`:
```python
DEDUP_KEY_COLS = ["fecha", "monto_usd", "bin", "nombre_comercio", "herramienta"]
```

Cuidado: Cambiar esto invalida hashes históricos (debes resetear la base).

---

## 🐛 Errores Comunes

### Warning: "Alta % de NA en columna X"
**Causa**: Columna no se mapeó correctamente desde Access.

**Diagnóstico**:
1. Revisar `diagnosticos/mapping_usado.csv`
2. Buscar la columna en `columna_origen`
3. Si es `null` → no encontró match

**Solución**:
Agregar sinónimo en `config/schemas.py`:
```python
"nombre_comercio": [
    "nombre de comercio",
    "comercio",
    "nuevo_nombre_access",  # ← Agregar aquí
    ...
]
```

### Parse fails: >10% en fecha
**Causa**: Formato de fecha no reconocido.

**Diagnóstico**:
Revisar `diagnosticos/parse_fallos.csv`, columna `valor_original`.

**Solución**:
Agregar formato en `src/transformers/parsers.py`:
```python
.when(pl.col(col_name).str.len_chars() == 10)
.then(pl.col(col_name).str.to_date("%d/%m/%Y", strict=False))  # Nuevo formato
```

### Error: "Table already exists"
**Causa**: Ya ejecutaste el pipeline antes y la tabla existe.

**Solución Normal** (append):
No hagas nada, es el comportamiento esperado.

**Solución Reset**:
```bash
python utils_historico.py
# Opción 5: RESET completo
```

### Performance lento: >10 min ejecución incremental
**Diagnóstico**:
1. Revisar logs: ¿Qué step es lento?
2. Revisar `diagnosticos/duplicados_detectados.csv`: ¿Muchos duplicados?

**Soluciones**:
- Si muchos duplicados internos → revisar fuente Access (¿por qué duplica?)
- Si hash check lento → ejecutar `VACUUM` en SQLite
- Si lectura Access lenta → Access DB muy grande, considerar exportar a CSV

---

## 📊 Power BI

### ¿DirectQuery o Import?
**DirectQuery**:
- ✅ Datos siempre actualizados
- ❌ Queries lentas si >5M registros
- Ideal para: Dashboards ejecutivos

**Import**:
- ✅ Rápido (todo en RAM)
- ❌ Requiere refresh manual
- Ideal para: Análisis ad-hoc con filtros complejos

**Recomendación**: Empieza con Import, cambia a DirectQuery si necesitas dato en vivo.

### ¿Cómo conecto Power BI a SQLite?
1. Instalar [SQLite ODBC Driver](http://www.ch-werner.de/sqliteodbc/)
2. Power BI → Obtener datos → Base de datos → ODBC
3. DSN: Crear nuevo DSN apuntando a `data/historico/master.db`
4. Seleccionar tabla `master_consolidado`

### Mis medidas DAX están lentas
**Optimizaciones**:
1. Usar vistas materializadas en SQLite:
```sql
CREATE VIEW resumen_diario AS
SELECT fecha, herramienta, COUNT(*) as cant, SUM(monto_usd) as monto
FROM master_consolidado
GROUP BY fecha, herramienta;
```

2. Importar esta vista en Power BI en lugar de la tabla completa.

3. Crear índices en SQLite:
```sql
CREATE INDEX idx_fecha_herr ON master_consolidado(fecha, herramienta);
```

### ¿Puedo usar Parquet en lugar de SQLite para Power BI?
Sí, Power BI soporta Parquet:
```python
# Exportar desde SQLite
with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
    df = loader.query("SELECT * FROM master_consolidado")
    df.write_parquet("data/processed/master_consolidado.parquet")
```

Luego en Power BI: Obtener datos → Archivo → Parquet

**Trade-off**: Parquet es más rápido, pero no soporta incremental (debes reescribir todo).

---

## 🔐 Seguridad y Privacidad

### ¿Los datos están encriptados en SQLite?
No por defecto. SQLite estándar no encripta.

Si necesitas encriptación:
1. Usar [SQLCipher](https://www.zetetic.net/sqlcipher/)
2. O encriptar el archivo `.db` con BitLocker/VeraCrypt

### ¿Dónde se guardan los logs?
En `logs/pipeline_YYYYMMDD_HHMMSS.log` en texto plano.

**⚠️ Cuidado**: Logs pueden contener datos sensibles (nombres de comercios, montos).
Recomendación: Agregar a `.gitignore` y no compartir públicamente.

### ¿Se pueden recuperar registros eliminados?
No directamente. SQLite no tiene "papelera de reciclaje".

**Prevención**:
- Hacer backups antes de operaciones destructivas
- Usar soft deletes (columna `deleted_at` en lugar de `DELETE`)

---

## 🚀 Escalabilidad

### ¿Cuántos registros soporta?
**Actual (SQLite)**:
- Cómodo: hasta 10M registros
- Funcional: hasta 50M registros (con índices bien diseñados)
- Límite práctico: Performance se degrada >50M

**Si creces más**:
- Migrar a PostgreSQL/SQL Server
- Particionar por año
- Considerar DuckDB (mejor analytics que SQLite)

### ¿Puedo procesar en chunks?
Sí, Polars soporta streaming:
```python
df = pl.scan_csv("archivo_gigante.csv")  # Lazy, no carga todo
df_filtrado = df.filter(pl.col("fecha") > "2025-01-01")
df_filtrado.collect(streaming=True)  # Procesa en chunks
```

No implementado actualmente, pero fácil agregar.

### ¿Qué hago si Access DB es >5 GB?
**Opciones**:
1. Exportar Access a CSV/Parquet (más rápido de leer)
2. Leer Access en chunks con filtros SQL
3. Migrar Access → SQL Server permanentemente

---

## 🧪 Testing

### ¿Cómo pruebo sin afectar producción?
1. Usar base SQLite separada:
```python
from config.paths import HISTORICO_DIR
test_db = HISTORICO_DIR / "master_test.db"
loader = SQLiteLoader(test_db, MASTER_TABLE)
```

2. O crear entorno virtual separado:
```bash
python -m venv venv_test
source venv_test/bin/activate
```

### ¿Hay tests unitarios?
No incluidos (v1.0), pero estructura modular facilita:
```python
# test_parsers.py
from src.transformers.parsers import parse_fecha_column
import polars as pl

def test_parse_fecha_yyyymmdd():
    df = pl.DataFrame({"fecha": ["20250115", "20250116"]})
    df_parsed, _ = parse_fecha_column(df)
    assert df_parsed["fecha"][0] == date(2025, 1, 15)
```

---

## 🎯 Casos de Uso

### ¿Puedo usar esto para otras herramientas (no Access)?
Sí, solo crea nuevo extractor:

```python
# src/extractors/csv_reader.py
def read_csv_file(path: Path) -> pl.DataFrame:
    return pl.read_csv(path, encoding="utf8")

# En main.py
df_nueva = read_csv_file(Path("nueva_fuente.csv"))
df_nueva = self.process_tool("NUEVA_HERRAMIENTA", df_nueva)
```

### ¿Puedo exportar a Excel para reportes?
Sí:
```python
with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
    df = loader.query("SELECT * FROM master_consolidado LIMIT 10000")
    df.write_excel("reporte.xlsx")
```

### ¿Funciona para análisis ML?
Sí, exporta Parquet y usa con scikit-learn/tensorflow:
```python
df = pl.read_parquet("data/processed/master_consolidado.parquet")
X = df.select(["monto_usd", "entry_mode", ...])
y = df["es_fraude"]
```

---

## 📞 Soporte

### ¿Dónde reporto bugs?
Por ahora: documentar en `logs/` y resolver manualmente.

Futuro: GitHub Issues si se versiona el proyecto.

### ¿Cómo contribuyo mejoras?
1. Forkear proyecto
2. Crear branch: `feature/nueva-funcionalidad`
3. Implementar + documentar
4. Pull request

### ¿Quién mantiene esto?
Actualmente: Myke (Scotiabank Perú)
Futuro: Posiblemente equipo de Prevención de Fraude

---

## 🔄 Migración desde Código Anterior

### ¿Puedo correr ambos sistemas en paralelo?
Sí, recomendado durante validación:
1. Mantén tu script actual
2. Ejecuta nueva arquitectura en SQLite separado
3. Compara resultados 2-3 semanas
4. Si validado → migra completamente

### ¿Cómo migro histórico existente?
Si tienes CSVs/Parquets históricos:
```python
# Leer histórico
df_historico = pl.read_parquet("historico_antiguo.parquet")

# Normalizar a esquema master
# ... (mismo pipeline)

# Cargar a SQLite
with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
    loader.insert_dataframe(df_historico, if_exists="append")
```

---

**Última actualización**: Marzo 2026  
**Versión FAQ**: 1.0
