# 🛡️ Pipeline de Consolidación de Herramientas Antifraude

Sistema ETL modular para consolidar datos transaccionales de múltiples herramientas de prevención de fraude.

---

## 📋 Tabla de Contenidos

- [Arquitectura](#arquitectura)
- [Características](#características)
- [Instalación](#instalación)
- [Uso](#uso)
- [Estructura del Proyecto](#estructura-del-proyecto)
- [Configuración](#configuración)
- [Reportes de Diagnóstico](#reportes-de-diagnóstico)

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────┐
│  FUENTES                                 │
│  VRM │ FRM │ RT_Débito │ RT_Crédito │ VCAS│
└──────────────┬──────────────────────────┘
               │
    ┌──────────▼──────────┐
    │  EXTRACTION          │
    │  (Access/CSV readers)│
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │  TRANSFORMATION      │
    │  • Normalización     │
    │  • Parseo tipos      │
    │  • Deduplicación     │
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │  LOAD                │
    │  SQLite (incremental)│
    └──────────┬──────────┘
               │
    ┌──────────▼──────────┐
    │  POWER BI            │
    └──────────────────────┘
```

### Flujo de Datos

1. **Extracción**: Lee desde Access/CSV
2. **Normalización**: Mapea columnas a esquema master
3. **Parseo**: Fecha → Date, Monto → Float64
4. **Deduplicación**: Hash composite key (fecha + monto + bin + comercio + herramienta)
5. **Carga incremental**: Solo inserta registros nuevos
6. **Diagnóstico**: Genera reportes de calidad

---

## ✨ Características

### 🚀 Performance
- **Polars**: 5-10x más rápido que Pandas
- **Lazy evaluation**: Optimización automática de queries
- **Carga incremental**: Solo procesa datos nuevos

### 🔍 Calidad de Datos
- **Normalización robusta**: Maneja múltiples formatos de columnas
- **Validación de tipos**: Parseo explícito con reporte de fallos
- **Deduplicación**: Hash-based, interno y vs histórico

### 📊 Observabilidad
- **Logging estructurado**: Métricas por herramienta
- **Reportes automáticos**: Mapping, NA%, parse fails, duplicados
- **Auditoría completa**: Fecha de carga por registro

### 🔧 Mantenibilidad
- **Modular**: Separación clara ETL
- **Configuración centralizada**: Paths y schemas en `config/`
- **Type hints**: Código autodocumentado

---

## 📦 Instalación

### Requisitos
- Python 3.10+
- Microsoft Access Driver (ODBC)
- SQLite 3

### Setup

```bash
# Clonar proyecto
cd proyecto_fraude

# Crear entorno virtual
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# Instalar dependencias
pip install -r requirements.txt
```

### Configurar rutas

Editar `config/paths.py`:

```python
ACCESS_BASE = Path(r"C:\Users\TU_USUARIO\...\BBDD")
```

---

## 🚀 Uso

### Ejecución básica

```bash
python main.py
```

Esto ejecuta el pipeline completo en modo **incremental** (solo carga datos nuevos).

### Carga completa (primera vez)

```python
from main import FraudPipeline

pipeline = FraudPipeline(incremental=False)
pipeline.run()
```

### Consultar datos desde Python

```python
from src.loaders.sqlite_loader import SQLiteLoader
from config.paths import MASTER_DB, MASTER_TABLE

with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
    # Total de registros
    total = loader.get_row_count()
    
    # Query personalizado
    df = loader.query("""
        SELECT herramienta, COUNT(*) as cant
        FROM master_consolidado
        GROUP BY herramienta
    """)
    
    print(df)
```

### Conectar Power BI

1. **Tipo de conexión**: SQLite (requiere driver ODBC SQLite)
2. **Ruta**: `data/historico/master.db`
3. **Tabla**: `master_consolidado`
4. **Modo recomendado**: DirectQuery (datos siempre actualizados)

---

## 📁 Estructura del Proyecto

```
proyecto_fraude/
│
├── config/                      # Configuración centralizada
│   ├── paths.py                 # Rutas de archivos
│   └── schemas.py               # Esquemas y mapeo de columnas
│
├── src/                         # Código fuente
│   ├── extractors/              # Lectura de fuentes
│   │   └── access_reader.py     # Reader de Access con Polars
│   │
│   ├── transformers/            # Transformaciones
│   │   ├── normalizer.py        # Mapeo a esquema master
│   │   ├── parsers.py           # Parseo de fecha/monto
│   │   └── deduplicator.py      # Deduplicación por hash
│   │
│   ├── loaders/                 # Carga a destinos
│   │   └── sqlite_loader.py     # Loader SQLite incremental
│   │
│   └── utils/
│       └── logger.py            # Sistema de logging
│
├── data/
│   ├── processed/               # Parquets intermedios
│   ├── diagnosticos/            # Reportes de calidad
│   └── historico/
│       └── master.db            # SQLite consolidado
│
├── logs/                        # Logs de ejecución
│
├── main.py                      # Orquestador principal
├── requirements.txt
└── README.md
```

---

## ⚙️ Configuración

### Esquema Master (`config/schemas.py`)

Define las columnas finales y sus tipos:

```python
MASTER_SCHEMA = {
    "fecha": pl.Date,
    "monto_usd": pl.Float64,
    "bin": pl.Utf8,
    "nombre_comercio": pl.Utf8,
    "entry_mode": pl.Utf8,
    "codigo_pais": pl.Utf8,
    "concresultado_vcas": pl.Utf8,
    "herramienta": pl.Utf8,
    "fecha_carga": pl.Datetime,
    "hash_id": pl.Utf8
}
```

### Mapeo de Columnas

Cada campo master tiene sinónimos reconocidos:

```python
COLUMN_SYNONYMS = {
    "fecha": [
        "fecha", "acf-fecha trx", "rt-fecha trx"
    ],
    "monto_usd": [
        "monto usd", "acf-monto dollar"
    ],
    ...
}
```

### Filtros de Negocio

```python
FILTROS_HERRAMIENTAS = {
    "FRM": {
        "excluir_condicion": ["NM", "RD"],
        "solo_de39": "63"
    },
    "RT_CREDITO": {
        "fecha_minima": "2025-06-01"
    }
}
```

---

## 📊 Reportes de Diagnóstico

Generados automáticamente en `data/diagnosticos/`:

### 1. `mapping_usado.csv`
Muestra qué columna de origen alimentó cada campo master.

| herramienta | campo_master | columna_origen | metodo_match |
|-------------|--------------|----------------|--------------|
| VRM         | fecha        | acf-fecha trx  | exact        |
| FRM         | codigo_pais  | de61.13 pais...| substring    |

### 2. `parse_fallos.csv`
Valores que no pudieron parsearse.

| herramienta | tipo_fallo | valor_original | valor_parseado |
|-------------|------------|----------------|----------------|
| VCAS        | fecha      | 20250230       | null           |

### 3. `duplicados_detectados.csv`
Registros duplicados encontrados.

| hash_id | fecha      | monto_usd | herramienta | tipo_duplicado |
|---------|------------|-----------|-------------|----------------|
| abc123  | 2025-01-15 | 150.00    | VRM         | interno        |

---

## 🔧 Casos de Uso Avanzados

### Agregar nueva herramienta

1. Editar `config/paths.py`:
```python
RUTA_BD_NUEVA = ACCESS_BASE / "nueva_herramienta.accdb"
TABLA_NUEVA = "tabla_nueva"
```

2. Editar `config/schemas.py` si tiene columnas específicas

3. Agregar en `main.py`:
```python
df_nueva_raw = read_access_table(RUTA_BD_NUEVA, TABLA_NUEVA)
df_nueva = self.process_tool("NUEVA", df_nueva_raw)
```

4. Agregar a consolidación:
```python
master_df = pl.concat([..., df_nueva])
```

### Análisis exploratorio

```python
import polars as pl
from config.paths import MASTER_DB

# Leer tabla completa
df = pl.read_database(
    f"SELECT * FROM master_consolidado",
    f"sqlite:///{MASTER_DB}"
)

# Análisis
print(df.group_by("herramienta").agg([
    pl.count().alias("registros"),
    pl.col("monto_usd").sum().alias("monto_total")
]))
```

---

## 🐛 Troubleshooting

### Error: "Microsoft Access Driver not found"

**Solución**: Instalar [Microsoft Access Database Engine](https://www.microsoft.com/en-us/download/details.aspx?id=54920)

### Error: "Table already exists"

**Solución**: La tabla SQLite ya existe. Si quieres recrearla:

```python
import sqlite3
from config.paths import MASTER_DB

conn = sqlite3.connect(MASTER_DB)
conn.execute("DROP TABLE IF EXISTS master_consolidado")
conn.close()
```

### Warning: "Alta % de NA en columna X"

**Diagnóstico**: Revisar `diagnosticos/mapping_usado.csv` para verificar si la columna se mapeó correctamente.

---

## 📈 Roadmap

- [ ] Integración con GitHub Actions para ejecución automática
- [ ] Dashboard Streamlit para monitoreo en vivo
- [ ] Conector directo Polars → Power BI (sin SQLite)
- [ ] Soporte para fuentes PostgreSQL/SQL Server
- [ ] Pipeline de validación con Great Expectations

---

## 👤 Autor

**Myke (Marcial Flores)**  
Analista de Prevención de Fraude - Scotiabank Perú

---

## 📄 Licencia

Uso interno - Scotiabank Perú
