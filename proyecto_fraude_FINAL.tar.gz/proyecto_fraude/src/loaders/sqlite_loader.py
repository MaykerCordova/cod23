"""
Cargador de datos a SQLite.
Maneja creación de tablas, carga incremental y consultas.
"""
import polars as pl
import sqlite3
from pathlib import Path
from typing import Optional, List
from datetime import datetime

from config.schemas import MASTER_SCHEMA
from src.utils.logger import setup_logger

logger = setup_logger("loaders.sqlite")


class SQLiteLoader:
    """
    Gestor de carga de datos a SQLite con soporte incremental.
    """
    
    def __init__(self, db_path: Path, table_name: str = "master_consolidado"):
        """
        Args:
            db_path: Ruta al archivo SQLite
            table_name: Nombre de la tabla master
        """
        self.db_path = db_path
        self.table_name = table_name
        self.conn = None
        
        # Crear directorio si no existe
        db_path.parent.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"SQLite DB: {db_path}")
    
    def connect(self):
        """Establece conexión con SQLite."""
        if self.conn is None:
            self.conn = sqlite3.connect(self.db_path)
            logger.debug("Conexión SQLite establecida")
    
    def close(self):
        """Cierra conexión."""
        if self.conn:
            self.conn.close()
            self.conn = None
            logger.debug("Conexión SQLite cerrada")
    
    def __enter__(self):
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
    
    def table_exists(self) -> bool:
        """Verifica si la tabla master existe."""
        self.connect()
        cursor = self.conn.cursor()
        cursor.execute(
            f"SELECT name FROM sqlite_master WHERE type='table' AND name='{self.table_name}'"
        )
        exists = cursor.fetchone() is not None
        logger.debug(f"Tabla '{self.table_name}' existe: {exists}")
        return exists
    
    def create_table(self, schema: dict = MASTER_SCHEMA):
        """
        Crea tabla master si no existe.
        
        Args:
            schema: Diccionario {columna: tipo_polars}
        """
        self.connect()
        
        # Mapeo tipos Polars → SQLite
        type_map = {
            pl.Date: "DATE",
            pl.Datetime: "DATETIME",
            pl.Float64: "REAL",
            pl.Int64: "INTEGER",
            pl.Utf8: "TEXT"
        }
        
        # Construir DDL
        cols_ddl = []
        for col_name, pl_type in schema.items():
            sqlite_type = type_map.get(pl_type, "TEXT")
            cols_ddl.append(f"{col_name} {sqlite_type}")
        
        # Agregar constraint de PK en hash_id
        cols_ddl.append("PRIMARY KEY (hash_id)")
        
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.table_name} (
            {', '.join(cols_ddl)}
        )
        """
        
        self.conn.execute(ddl)
        self.conn.commit()
        
        # Índices para performance
        self.conn.execute(
            f"CREATE INDEX IF NOT EXISTS idx_fecha ON {self.table_name}(fecha)"
        )
        self.conn.execute(
            f"CREATE INDEX IF NOT EXISTS idx_herramienta ON {self.table_name}(herramienta)"
        )
        self.conn.commit()
        
        logger.info(f"Tabla '{self.table_name}' creada con índices")
    
    def get_existing_hashes(self) -> List[str]:
        """
        Obtiene todos los hash_id existentes en la tabla.
        
        Returns:
            Lista de hashes (strings)
        """
        if not self.table_exists():
            return []
        
        self.connect()
        
        query = f"SELECT hash_id FROM {self.table_name}"
        df = pl.read_database(query, self.conn)
        
        hashes = df["hash_id"].to_list()
        
        logger.info(f"Cargados {len(hashes):,} hashes existentes")
        
        return hashes
    
    def get_last_date_by_tool(self, herramienta: str) -> Optional[str]:
        """
        Obtiene la última fecha cargada para una herramienta.
        
        Args:
            herramienta: Nombre de la herramienta
            
        Returns:
            Fecha en formato 'YYYY-MM-DD' o None
        """
        if not self.table_exists():
            return None
        
        self.connect()
        
        query = f"""
        SELECT MAX(fecha) as max_fecha
        FROM {self.table_name}
        WHERE herramienta = '{herramienta}'
        """
        
        df = pl.read_database(query, self.conn)
        
        if len(df) > 0 and df["max_fecha"][0] is not None:
            last_date = str(df["max_fecha"][0])
            logger.info(f"Última fecha {herramienta}: {last_date}")
            return last_date
        
        return None
    
    def insert_dataframe(self, df: pl.DataFrame, if_exists: str = "append"):
        """
        Inserta DataFrame en SQLite.
        
        Args:
            df: DataFrame a insertar
            if_exists: 'append' | 'replace' | 'fail'
        """
        if len(df) == 0:
            logger.warning("DataFrame vacío, no se insertó nada")
            return
        
        self.connect()
        
        # Agregar timestamp de carga
        df = df.with_columns(
            pl.lit(datetime.now()).alias("fecha_carga")
        )
        
        # Insertar
        df.write_database(
            table_name=self.table_name,
            connection=self.conn,
            if_table_exists=if_exists
        )
        
        logger.info(f"Insertados {len(df):,} registros en '{self.table_name}'")
    
    def get_row_count(self) -> int:
        """Retorna cantidad total de registros."""
        if not self.table_exists():
            return 0
        
        self.connect()
        
        query = f"SELECT COUNT(*) as count FROM {self.table_name}"
        df = pl.read_database(query, self.conn)
        
        return int(df["count"][0])
    
    def query(self, sql: str) -> pl.DataFrame:
        """
        Ejecuta query SQL y retorna DataFrame.
        
        Args:
            sql: Query SQL
            
        Returns:
            DataFrame con resultados
        """
        self.connect()
        return pl.read_database(sql, self.conn)
