"""
Normalización de nombres de columnas y valores.
Implementa lógica de mapeo de sinónimos y limpieza de datos.
"""
import polars as pl
import unicodedata
import re
from typing import Dict, List, Tuple

from config.schemas import COLUMN_SYNONYMS, MASTER_SCHEMA
from src.utils.logger import setup_logger

logger = setup_logger("transformers.normalizer")


def normalize_string(text: str) -> str:
    """
    Normaliza texto: lowercase, sin acentos, sin espacios extra.
    
    Args:
        text: Texto a normalizar
        
    Returns:
        Texto normalizado
    """
    # Lowercase
    text = str(text).strip().lower()
    
    # Reemplazar espacio no-breakable
    text = text.replace("\u00A0", " ")
    
    # Quitar acentos (NFKD decomposition)
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    
    # Espacios múltiples → un espacio
    text = re.sub(r"\s+", " ", text)
    
    return text


def normalize_column_names(df: pl.DataFrame) -> pl.DataFrame:
    """
    Normaliza nombres de columnas de un DataFrame.
    
    Args:
        df: DataFrame original
        
    Returns:
        DataFrame con columnas normalizadas
    """
    # Crear mapping: columna_original → columna_normalizada
    rename_map = {
        col: normalize_string(col)
        for col in df.columns
    }
    
    return df.rename(rename_map)


def find_column_match(
    available_cols: List[str],
    master_field: str,
    synonyms: List[str]
) -> Tuple[str | None, str]:
    """
    Busca coincidencia de columna por sinónimos.
    
    Args:
        available_cols: Columnas disponibles en el DataFrame (normalizadas)
        master_field: Nombre del campo master
        synonyms: Lista de sinónimos normalizados
        
    Returns:
        (columna_encontrada, metodo_match)
        metodo_match: "exact" | "substring" | None
    """
    # 1. Match exacto
    for syn in synonyms:
        if syn in available_cols:
            return syn, "exact"
    
    # 2. Match por substring (solo para casos especiales)
    if master_field == "codigo_pais":
        for col in available_cols:
            if "pais del pos" in col or "de61.13" in col:
                return col, "substring"
    
    return None, "not_found"


def map_to_master_schema(
    df: pl.DataFrame,
    herramienta: str
) -> Tuple[pl.DataFrame, pl.DataFrame]:
    """
    Mapea columnas del DataFrame original al esquema master.
    
    Args:
        df: DataFrame normalizado
        herramienta: Nombre de la herramienta (para reportes)
        
    Returns:
        (df_mapeado, reporte_mapping)
    """
    available_cols = df.columns
    rename_map = {}
    mapping_report = []
    
    # Normalizar sinónimos (si no están ya normalizados)
    synonyms_norm = {
        master_field: [normalize_string(s) for s in syns]
        for master_field, syns in COLUMN_SYNONYMS.items()
    }
    
    # Buscar cada campo master
    for master_field, synonyms in synonyms_norm.items():
        found_col, method = find_column_match(available_cols, master_field, synonyms)
        
        if found_col:
            rename_map[found_col] = master_field
            logger.debug(f"{herramienta} | {master_field} ← {found_col} ({method})")
        else:
            logger.warning(f"{herramienta} | Campo '{master_field}' no encontrado")
        
        # Reporte
        mapping_report.append({
            "herramienta": herramienta,
            "campo_master": master_field,
            "columna_origen": found_col,
            "metodo_match": method,
            "sinonimos_intentados": "; ".join(synonyms[:5])  # Primeros 5
        })
    
    # Renombrar columnas encontradas
    df_renamed = df.rename(rename_map)
    
    # Crear columnas faltantes como nulls
    for master_field in COLUMN_SYNONYMS.keys():
        if master_field not in df_renamed.columns:
            df_renamed = df_renamed.with_columns(
                pl.lit(None).cast(MASTER_SCHEMA.get(master_field, pl.Utf8)).alias(master_field)
            )
    
    # Crear reporte
    report_df = pl.DataFrame(mapping_report)
    
    return df_renamed, report_df


def clean_string_columns(df: pl.DataFrame) -> pl.DataFrame:
    """
    Limpia columnas de texto: strip, uppercase para códigos.
    
    Args:
        df: DataFrame con columnas ya mapeadas
        
    Returns:
        DataFrame con columnas limpias
    """
    return (
        df
        .with_columns([
            # Strings: strip
            pl.col("nombre_comercio").str.strip_chars(),
            pl.col("codigo_pais").str.strip_chars().str.to_uppercase(),
            pl.col("entry_mode").str.strip_chars().str.to_uppercase(),
            pl.col("concresultado_vcas").str.strip_chars()
        ])
    )
