"""
Parsers de fecha y monto optimizados con expresiones Polars.
Maneja múltiples formatos y genera reportes de fallos.
"""
import polars as pl
from typing import Tuple

from src.utils.logger import setup_logger

logger = setup_logger("transformers.parsers")


def parse_fecha_column(df: pl.DataFrame, col_name: str = "fecha") -> Tuple[pl.DataFrame, pl.DataFrame]:
    """
    Parsea columna de fecha manejando múltiples formatos.
    
    Formatos soportados:
    - YYYYMMDD (8 dígitos)
    - YYYY-MM-DD
    - YYYY/MM/DD
    - DD/MM/YYYY (dayfirst=True)
    
    Args:
        df: DataFrame con columna a parsear
        col_name: Nombre de la columna de fecha
        
    Returns:
        (df_parseado, reporte_fallos)
    """
    if col_name not in df.columns:
        logger.warning(f"Columna '{col_name}' no existe en DataFrame")
        return df, pl.DataFrame()
    
    # Guardar valores originales para reporte de fallos
    col_original = f"{col_name}_original"
    df = df.with_columns(pl.col(col_name).alias(col_original))
    
    # Estrategia multi-formato
    df = (
        df
        .with_columns([
            # Convertir a string y limpiar
            pl.col(col_name)
            .cast(pl.Utf8)
            .str.strip_chars()
            .str.replace_all(r"\.0$", "")  # Quitar .0 de floats
            .str.replace_all("/", "-")      # Normalizar separadores
            .alias(col_name)
        ])
        .with_columns([
            # Intentar parsear como fecha
            pl.when(pl.col(col_name).str.len_chars() == 8)
            # Formato YYYYMMDD
            .then(pl.col(col_name).str.to_date("%Y%m%d", strict=False))
            # Formato YYYY-MM-DD o variantes
            .otherwise(pl.col(col_name).str.to_date("%Y-%m-%d", strict=False))
            .alias(col_name)
        ])
    )
    
    # Detectar fallos de parseo
    fallos = (
        df
        .filter(
            pl.col(col_name).is_null() &
            pl.col(col_original).is_not_null() &
            (pl.col(col_original).cast(pl.Utf8).str.strip_chars() != "")
        )
        .select([
            pl.lit("fecha").alias("tipo_fallo"),
            pl.col(col_original).alias("valor_original"),
            pl.col(col_name).alias("valor_parseado")
        ])
        .head(20)  # Limitar ejemplos
    )
    
    if len(fallos) > 0:
        logger.warning(f"Detectados {len(fallos)} fallos de parseo en '{col_name}'")
    
    # Eliminar columna temporal
    df = df.drop(col_original)
    
    return df, fallos


def parse_monto_column(df: pl.DataFrame, col_name: str = "monto_usd") -> Tuple[pl.DataFrame, pl.DataFrame]:
    """
    Parsea columna de monto a Float64.
    
    Args:
        df: DataFrame con columna a parsear
        col_name: Nombre de la columna de monto
        
    Returns:
        (df_parseado, reporte_fallos)
    """
    if col_name not in df.columns:
        logger.warning(f"Columna '{col_name}' no existe en DataFrame")
        return df, pl.DataFrame()
    
    # Guardar valores originales
    col_original = f"{col_name}_original"
    df = df.with_columns(pl.col(col_name).alias(col_original))
    
    # Parsear a float
    df = df.with_columns(
        pl.col(col_name).cast(pl.Float64, strict=False).alias(col_name)
    )
    
    # Detectar fallos
    fallos = (
        df
        .filter(
            pl.col(col_name).is_null() &
            pl.col(col_original).is_not_null() &
            (pl.col(col_original).cast(pl.Utf8).str.strip_chars() != "")
        )
        .select([
            pl.lit("monto").alias("tipo_fallo"),
            pl.col(col_original).alias("valor_original"),
            pl.col(col_name).alias("valor_parseado")
        ])
        .head(20)
    )
    
    if len(fallos) > 0:
        logger.warning(f"Detectados {len(fallos)} fallos de parseo en '{col_name}'")
    
    df = df.drop(col_original)
    
    return df, fallos


def parse_master_columns(df: pl.DataFrame, herramienta: str) -> Tuple[pl.DataFrame, pl.DataFrame]:
    """
    Parsea todas las columnas críticas del esquema master.
    
    Args:
        df: DataFrame con columnas master ya mapeadas
        herramienta: Nombre de herramienta (para reporte)
        
    Returns:
        (df_parseado, reporte_fallos_consolidado)
    """
    # Parsear fecha
    df, fallos_fecha = parse_fecha_column(df, "fecha")
    
    # Parsear monto
    df, fallos_monto = parse_monto_column(df, "monto_usd")
    
    # Consolidar fallos
    fallos_list = []
    if len(fallos_fecha) > 0:
        fallos_list.append(fallos_fecha.with_columns(pl.lit(herramienta).alias("herramienta")))
    if len(fallos_monto) > 0:
        fallos_list.append(fallos_monto.with_columns(pl.lit(herramienta).alias("herramienta")))
    
    fallos_total = pl.concat(fallos_list) if fallos_list else pl.DataFrame()
    
    return df, fallos_total
