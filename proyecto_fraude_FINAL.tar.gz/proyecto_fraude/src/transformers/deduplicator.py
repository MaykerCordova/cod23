"""
Deduplicación de registros usando composite key.
Genera hash único por combinación de campos críticos.
"""
import polars as pl
from typing import List

from config.schemas import DEDUP_KEY_COLS
from src.utils.logger import setup_logger

logger = setup_logger("transformers.dedup")


def generate_hash_id(df: pl.DataFrame, key_cols: List[str] = DEDUP_KEY_COLS) -> pl.DataFrame:
    """
    Genera columna hash_id basada en composite key.
    
    Args:
        df: DataFrame con datos
        key_cols: Columnas que forman la clave compuesta
        
    Returns:
        DataFrame con columna 'hash_id' añadida
    """
    # Verificar que existan las columnas
    missing_cols = [col for col in key_cols if col not in df.columns]
    if missing_cols:
        logger.warning(f"Columnas faltantes para hash: {missing_cols}")
        # Usar solo las disponibles
        key_cols = [col for col in key_cols if col in df.columns]
    
    # Concatenar campos (convertir todo a string)
    df = df.with_columns([
        pl.concat_str(
            [pl.col(c).cast(pl.Utf8).fill_null("NULL") for c in key_cols],
            separator="|"
        )
        .hash()
        .cast(pl.Utf8)
        .alias("hash_id")
    ])
    
    logger.debug(f"Hash generado usando columnas: {key_cols}")
    
    return df


def detect_duplicates_within(df: pl.DataFrame) -> pl.DataFrame:
    """
    Detecta duplicados DENTRO del mismo DataFrame.
    
    Args:
        df: DataFrame con columna 'hash_id'
        
    Returns:
        DataFrame solo con duplicados (para reporte)
    """
    if "hash_id" not in df.columns:
        logger.error("Columna 'hash_id' no existe. Ejecutar generate_hash_id() primero.")
        return pl.DataFrame()
    
    duplicados = (
        df
        .filter(pl.col("hash_id").is_duplicated())
        .sort("hash_id")
        .select(["hash_id", "fecha", "monto_usd", "nombre_comercio", "herramienta"])
    )
    
    if len(duplicados) > 0:
        logger.warning(f"Detectados {len(duplicados):,} registros duplicados INTERNOS")
    
    return duplicados


def remove_duplicates(df: pl.DataFrame, keep: str = "first") -> pl.DataFrame:
    """
    Elimina duplicados del DataFrame.
    
    Args:
        df: DataFrame con columna 'hash_id'
        keep: Estrategia ('first', 'last', 'none')
        
    Returns:
        DataFrame sin duplicados
    """
    if "hash_id" not in df.columns:
        logger.error("Columna 'hash_id' no existe.")
        return df
    
    filas_antes = len(df)
    
    df_unique = df.unique(subset=["hash_id"], keep=keep)
    
    filas_eliminadas = filas_antes - len(df_unique)
    
    if filas_eliminadas > 0:
        logger.info(f"Eliminados {filas_eliminadas:,} duplicados ({keep=})")
    
    return df_unique


def detect_duplicates_against_existing(
    df_new: pl.DataFrame,
    existing_hashes: pl.DataFrame | List[str]
) -> pl.DataFrame:
    """
    Detecta duplicados entre datos nuevos y hashes existentes en SQLite.
    
    Args:
        df_new: DataFrame nuevo con 'hash_id'
        existing_hashes: DataFrame con columna 'hash_id' o lista de hashes
        
    Returns:
        DataFrame con duplicados detectados
    """
    if "hash_id" not in df_new.columns:
        logger.error("Columna 'hash_id' no existe en df_new")
        return pl.DataFrame()
    
    # Convertir lista a DataFrame si es necesario
    if isinstance(existing_hashes, list):
        existing_hashes = pl.DataFrame({"hash_id": existing_hashes})
    
    # Anti-join: registros en df_new que YA están en existing
    duplicados = (
        df_new
        .join(existing_hashes.select("hash_id"), on="hash_id", how="semi")
        .select(["hash_id", "fecha", "monto_usd", "nombre_comercio", "herramienta"])
    )
    
    if len(duplicados) > 0:
        logger.warning(
            f"Detectados {len(duplicados):,} registros duplicados vs histórico"
        )
    
    return duplicados


def filter_only_new_records(
    df_new: pl.DataFrame,
    existing_hashes: pl.DataFrame | List[str]
) -> pl.DataFrame:
    """
    Filtra solo registros nuevos (que NO están en histórico).
    
    Args:
        df_new: DataFrame nuevo con 'hash_id'
        existing_hashes: DataFrame con 'hash_id' o lista de hashes
        
    Returns:
        DataFrame con solo registros nuevos
    """
    if isinstance(existing_hashes, list):
        existing_hashes = pl.DataFrame({"hash_id": existing_hashes})
    
    filas_antes = len(df_new)
    
    # Anti-join: mantener solo los que NO están en existing
    df_only_new = df_new.join(
        existing_hashes.select("hash_id"),
        on="hash_id",
        how="anti"
    )
    
    filas_nuevas = len(df_only_new)
    filas_duplicadas = filas_antes - filas_nuevas
    
    logger.info(
        f"Filtro incremental: {filas_nuevas:,} nuevos | {filas_duplicadas:,} duplicados"
    )
    
    return df_only_new
