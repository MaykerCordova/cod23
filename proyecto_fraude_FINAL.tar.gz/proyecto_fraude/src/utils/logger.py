"""
Sistema de logging estructurado para auditoría del pipeline.
Registra métricas de ETL, errores y diagnósticos.
"""
import logging
from datetime import datetime
from pathlib import Path
from config.paths import LOGS_DIR

def setup_logger(name: str = "pipeline", log_to_file: bool = True) -> logging.Logger:
    """
    Configura logger con formato estructurado.
    
    Args:
        name: Nombre del logger
        log_to_file: Si True, guarda logs en archivo
        
    Returns:
        Logger configurado
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    # Evitar duplicar handlers si ya existe
    if logger.handlers:
        return logger
    
    # Formato estructurado
    formatter = logging.Formatter(
        fmt='%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Handler consola
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)
    
    # Handler archivo (si se solicita)
    if log_to_file:
        LOGS_DIR.mkdir(parents=True, exist_ok=True)
        log_file = LOGS_DIR / f"pipeline_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"
        
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        logger.info(f"Log file: {log_file}")
    
    return logger


class MetricsLogger:
    """
    Helper para registrar métricas del pipeline de forma estructurada.
    """
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        
    def log_extraction(self, herramienta: str, filas: int, columnas: int):
        """Registra métricas de extracción."""
        self.logger.info(
            f"EXTRACT | {herramienta:12} | filas={filas:>8,} | cols={columnas:>3}"
        )
        
    def log_transformation(self, herramienta: str, filas_in: int, filas_out: int, 
                          na_before: dict = None, na_after: dict = None):
        """Registra métricas de transformación."""
        filas_perdidas = filas_in - filas_out
        pct_perdida = (filas_perdidas / filas_in * 100) if filas_in > 0 else 0
        
        self.logger.info(
            f"TRANSFORM | {herramienta:12} | in={filas_in:>8,} | out={filas_out:>8,} | "
            f"perdidas={filas_perdidas:>6,} ({pct_perdida:>5.2f}%)"
        )
        
        if na_before and na_after:
            for col, pct in na_after.items():
                if pct > 50:  # Alerta si >50% NA
                    self.logger.warning(
                        f"  ⚠️  {herramienta} | columna '{col}' tiene {pct:.1f}% NA"
                    )
    
    def log_load(self, herramienta: str, filas_insertadas: int, duplicados: int):
        """Registra métricas de carga."""
        self.logger.info(
            f"LOAD | {herramienta:12} | insertadas={filas_insertadas:>8,} | "
            f"duplicados={duplicados:>6,}"
        )
        
    def log_error(self, herramienta: str, step: str, error: Exception):
        """Registra errores."""
        self.logger.error(
            f"ERROR | {herramienta:12} | step={step} | {type(error).__name__}: {error}"
        )
