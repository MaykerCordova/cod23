"""
Extractor de datos desde bases Access.
Lee tablas completas o con filtros SQL, retorna Polars DataFrames.
"""
import polars as pl
import pyodbc
from typing import Optional
from pathlib import Path

from src.utils.logger import setup_logger

logger = setup_logger("extractors.access")


def read_access_table(
    db_path: Path,
    table_name: str,
    sql_filter: Optional[str] = None,
    lazy: bool = False
) -> pl.DataFrame | pl.LazyFrame:
    """
    Lee una tabla desde Access y retorna Polars DataFrame.
    
    Args:
        db_path: Ruta al archivo .accdb
        table_name: Nombre de la tabla
        sql_filter: Filtro SQL opcional (ej: "WHERE fecha > #2025-01-01#")
        lazy: Si True, retorna LazyFrame (recomendado para grandes volúmenes)
        
    Returns:
        DataFrame o LazyFrame con los datos
        
    Example:
        df = read_access_table(
            Path("base.accdb"),
            "transacciones",
            sql_filter="WHERE monto > 100"
        )
    """
    if not db_path.exists():
        raise FileNotFoundError(f"Base Access no encontrada: {db_path}")
    
    # Construir query SQL
    sql = f"SELECT * FROM {table_name}"
    if sql_filter:
        sql += f" {sql_filter}"
    
    logger.debug(f"Ejecutando SQL: {sql}")
    
    # Conexión Access
    conn_str = (
        r"DRIVER={Microsoft Access Driver (*.mdb, *.accdb)};"
        f"DBQ={db_path};"
    )
    
    try:
        with pyodbc.connect(conn_str) as conn:
            cursor = conn.cursor()
            cursor.execute(sql)
            
            # Obtener columnas
            columns = [col[0] for col in cursor.description]
            
            # Fetch datos
            rows = cursor.fetchall()
            
            # Convertir a diccionario por columnas
            data = {col: [] for col in columns}
            for row in rows:
                for i, col in enumerate(columns):
                    data[col].append(row[i])
            
            # Crear DataFrame Polars
            df = pl.DataFrame(data)
            
            logger.info(f"Leídos {len(df):,} registros desde {table_name}")
            
            return df.lazy() if lazy else df
            
    except pyodbc.Error as e:
        logger.error(f"Error leyendo Access {db_path} / {table_name}: {e}")
        raise


def read_access_incremental(
    db_path: Path,
    table_name: str,
    date_column: str,
    last_date: Optional[str] = None
) -> pl.DataFrame:
    """
    Lee solo registros nuevos desde Access basado en fecha.
    
    Args:
        db_path: Ruta al archivo .accdb
        table_name: Nombre de la tabla
        date_column: Columna de fecha para filtrar
        last_date: Última fecha cargada (formato 'YYYY-MM-DD')
        
    Returns:
        DataFrame con registros nuevos
        
    Example:
        df = read_access_incremental(
            Path("base.accdb"),
            "transacciones",
            "fecha_trx",
            last_date="2025-01-15"
        )
    """
    if last_date:
        # Formato Access para fechas: #YYYY-MM-DD#
        sql_filter = f"WHERE [{date_column}] > #{last_date}#"
        logger.info(f"Carga incremental desde {last_date}")
    else:
        sql_filter = None
        logger.info("Primera carga (sin filtro de fecha)")
    
    return read_access_table(db_path, table_name, sql_filter)
