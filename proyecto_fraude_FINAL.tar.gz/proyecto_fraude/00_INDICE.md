# 📚 ÍNDICE MAESTRO - Documentación del Proyecto

## 🎯 Guía Rápida de Navegación

Según tu objetivo, comienza por el documento apropiado:

---

## 📖 Para Empezar

### 👉 **Quiero entender qué construimos**
- Lee: [`README.md`](README.md)
- Tiempo: 10 minutos
- Aprenderás: Visión general, características, estructura básica

### 👉 **Quiero saber por qué tomamos estas decisiones**
- Lee: [`ARQUITECTURA.md`](ARQUITECTURA.md)
- Tiempo: 20 minutos
- Aprenderás: Trade-offs, comparativas, justificación técnica

### 👉 **Quiero implementar el sistema**
- Lee: [`IMPLEMENTACION.md`](IMPLEMENTACION.md)
- Tiempo: 15 minutos + 2-3 días implementación
- Aprenderás: Paso a paso, checklist, troubleshooting

### 👉 **Quiero comparar con mi código actual**
- Lee: [`COMPARATIVA_FLUJO.md`](COMPARATIVA_FLUJO.md)
- Tiempo: 15 minutos
- Aprenderás: Antes vs después, métricas, camino de migración

### 👉 **Quiero presentar el proyecto a stakeholders**
- Lee: [`RESUMEN_EJECUTIVO.md`](RESUMEN_EJECUTIVO.md)
- Tiempo: 10 minutos
- Aprenderás: ROI, resultados esperados, roadmap de implementación

---

## 🗂️ Documentación Técnica

### 📘 Documentos Principales

| Documento | Propósito | Audiencia | Prioridad |
|-----------|-----------|-----------|-----------|
| **RESUMEN_EJECUTIVO.md** | Overview para stakeholders | Management/Líderes | ⭐⭐⭐ |
| **README.md** | Guía de usuario y referencia rápida | Todos | ⭐⭐⭐ |
| **ARQUITECTURA.md** | Decisiones técnicas y diseño | Desarrolladores | ⭐⭐⭐ |
| **IMPLEMENTACION.md** | Guía de implementación paso a paso | Implementadores | ⭐⭐⭐ |
| **COMPARATIVA_FLUJO.md** | Análisis antes/después | Stakeholders técnicos | ⭐⭐ |
| **FAQ.md** | Preguntas frecuentes | Usuarios/Soporte | ⭐⭐ |

### 📗 Scripts de Ejemplo

| Script | Propósito | Cuándo Usar |
|--------|-----------|-------------|
| **main.py** | Orquestador principal | Ejecución diaria del pipeline |
| **analisis_exploratorio.py** | Queries de análisis | Validación post-carga |
| **utils_historico.py** | Gestión de SQLite | Backup, reset, estadísticas |
| **queries_powerbi.py** | Colección de queries SQL | Crear medidas en Power BI |

---

## 🎓 Rutas de Aprendizaje

### Para el Implementador (tú)

**Día 1: Entendimiento**
1. Leer `README.md` (10 min)
2. Leer `ARQUITECTURA.md` secciones 1-5 (30 min)
3. Revisar estructura de carpetas (10 min)
4. Explorar `main.py` línea por línea (30 min)

**Día 2: Setup**
5. Leer `IMPLEMENTACION.md` Paso 1-3 (15 min)
6. Configurar rutas en `config/paths.py` (5 min)
7. Instalar dependencias (5 min)
8. Primera ejecución con 1 mes de datos (30 min)
9. Revisar reportes de diagnóstico (20 min)

**Día 3: Validación**
10. Ejecutar `analisis_exploratorio.py` (15 min)
11. Comparar resultados vs código actual (1 hora)
12. Conectar Power BI (30 min)
13. Documentar ajustes necesarios (30 min)

**Día 4-5: Ajustes**
14. Ajustar sinónimos en `config/schemas.py` (variable)
15. Implementar filtros específicos (variable)
16. Validar con dataset completo (variable)

---

### Para el Equipo (futuro)

**Onboarding Básico (1 hora)**
1. `README.md` completo
2. Ejecutar `python main.py` una vez
3. Revisar logs en `logs/`
4. Explorar SQLite con `utils_historico.py`

**Onboarding Avanzado (4 horas)**
5. `ARQUITECTURA.md` completo
6. Revisar código en `src/` módulo por módulo
7. Modificar un transformer (ej: agregar columna)
8. Agregar una nueva herramienta de prueba

---

## 🔧 Referencia Rápida por Tarea

### Ejecutar el Pipeline
```bash
python main.py
```
Documentación: `README.md` sección "Uso"

### Ver Estadísticas de la Base
```bash
python utils_historico.py
# Opción 1
```
Documentación: `IMPLEMENTACION.md` sección "Casos de Uso"

### Crear Backup
```bash
python utils_historico.py
# Opción 2
```

### Análisis Exploratorio
```bash
python analisis_exploratorio.py
```
O editar el script para queries personalizadas

### Agregar Nueva Herramienta
1. Leer: `ARQUITECTURA.md` sección 9 (Casos de Uso Avanzados)
2. Editar: `config/paths.py` (agregar rutas)
3. Editar: `main.py` método `run()` (agregar extracción)
4. Ejecutar: `python main.py`

### Troubleshooting
Revisar en orden:
1. `logs/pipeline_YYYYMMDD_HHMMSS.log`
2. `data/diagnosticos/parse_fallos.csv`
3. `data/diagnosticos/mapping_usado.csv`
4. `IMPLEMENTACION.md` sección "Troubleshooting"

---

## 📦 Contenido del Proyecto

### Estructura Completa

```
proyecto_fraude/
│
├── 📘 Documentación
│   ├── README.md                    ← Guía principal
│   ├── ARQUITECTURA.md              ← Decisiones técnicas
│   ├── IMPLEMENTACION.md            ← Guía de implementación
│   └── COMPARATIVA_FLUJO.md         ← Antes vs Después
│
├── ⚙️ Configuración
│   └── config/
│       ├── paths.py                 ← Rutas centralizadas
│       └── schemas.py               ← Esquemas y mapeos
│
├── 🔧 Código Fuente
│   └── src/
│       ├── extractors/
│       │   └── access_reader.py     ← Lectura de Access
│       ├── transformers/
│       │   ├── normalizer.py        ← Mapeo de columnas
│       │   ├── parsers.py           ← Parseo de fecha/monto
│       │   └── deduplicator.py      ← Deduplicación
│       ├── loaders/
│       │   └── sqlite_loader.py     ← Carga a SQLite
│       └── utils/
│           └── logger.py            ← Sistema de logging
│
├── 🚀 Scripts Ejecutables
│   ├── main.py                      ← Orquestador principal
│   ├── analisis_exploratorio.py    ← Análisis post-carga
│   ├── utils_historico.py           ← Gestión de SQLite
│   └── queries_powerbi.py           ← Queries para Power BI
│
├── 💾 Datos (se crean al ejecutar)
│   └── data/
│       ├── processed/               ← Parquets intermedios
│       ├── diagnosticos/            ← Reportes de calidad
│       └── historico/
│           └── master.db            ← SQLite consolidado
│
├── 📝 Logs (se crean al ejecutar)
│   └── logs/
│       └── pipeline_*.log
│
└── 📦 Dependencias
    └── requirements.txt
```

---

## 🎯 Checklist de Implementación

Usa esta checklist mientras implementas:

### Fase 1: Setup
- [ ] Leer `README.md`
- [ ] Leer `IMPLEMENTACION.md` Paso 1-2
- [ ] Configurar rutas en `config/paths.py`
- [ ] Instalar dependencias: `pip install -r requirements.txt`
- [ ] Verificar Microsoft Access Driver instalado

### Fase 2: Primera Ejecución
- [ ] Ejecutar: `python main.py`
- [ ] Pipeline terminó sin errores
- [ ] Se creó `data/historico/master.db`
- [ ] Se crearon reportes en `data/diagnosticos/`
- [ ] Se creó log en `logs/`

### Fase 3: Validación
- [ ] Ejecutar: `python analisis_exploratorio.py`
- [ ] Revisar `diagnosticos/mapping_usado.csv` (todas las columnas mapeadas)
- [ ] Revisar `diagnosticos/parse_fallos.csv` (<5% fallos)
- [ ] Revisar `diagnosticos/duplicados_detectados.csv`
- [ ] Total de registros coincide con expectativa

### Fase 4: Power BI
- [ ] Instalar SQLite ODBC Driver
- [ ] Conectar Power BI a `master.db`
- [ ] Importar tabla `master_consolidado`
- [ ] Probar queries de `queries_powerbi.py`
- [ ] Crear primer dashboard

### Fase 5: Producción
- [ ] Validar con dataset completo
- [ ] Comparar resultados vs código actual
- [ ] Documentar diferencias encontradas
- [ ] Programar ejecución automática (Task Scheduler)
- [ ] Entrenar equipo en nueva arquitectura

---

## 📞 Soporte y Recursos Adicionales

### Archivos de Configuración Clave
- **Rutas**: `config/paths.py`
- **Esquemas**: `config/schemas.py`
- **Dependencias**: `requirements.txt`

### Logs y Diagnósticos
- **Logs de ejecución**: `logs/pipeline_*.log`
- **Mapping de columnas**: `data/diagnosticos/mapping_usado.csv`
- **Parse failures**: `data/diagnosticos/parse_fallos.csv`
- **Duplicados**: `data/diagnosticos/duplicados_detectados.csv`

### Base de Datos
- **Ubicación**: `data/historico/master.db`
- **Tabla**: `master_consolidado`
- **Gestión**: `python utils_historico.py`

---

## 🚀 Próximos Pasos Recomendados

1. **HOY**: Lee `README.md` y `IMPLEMENTACION.md`
2. **MAÑANA**: Configura rutas y ejecuta primera carga
3. **ESTA SEMANA**: Valida resultados y conecta Power BI
4. **PRÓXIMA SEMANA**: Migra a producción

---

## 📝 Versionado

- **v1.0** (Marzo 2026): Arquitectura base con Polars + SQLite
- **v1.1** (futuro): Agregar tests unitarios
- **v1.2** (futuro): Automatización con GitHub Actions
- **v2.0** (futuro): Integración ML para detección de fraude

---

**Versión de la documentación**: 1.0  
**Última actualización**: Marzo 2026  
**Autor**: Arquitectura diseñada para Myke @ Scotiabank Perú
