"""
Orquestador principal del pipeline ETL.
Ejecuta extracción, transformación y carga incremental.
"""
import polars as pl
from pathlib import Path
from datetime import datetime

# Config
from config.paths import (
    RUTA_BD_VRM, RUTA_BD_FRM, RUTA_BD_RT_D, RUTA_BD_RT_C,
    TABLA_VRM, TABLA_FRM, TABLA_RT_D, TABLA_RT_C,
    VCAS_CSV, MASTER_DB, MASTER_TABLE,
    REPORT_MAPPING, REPORT_NA, REPORT_PARSE_FAILS, REPORT_DUPLICADOS,
    ensure_directories
)
from config.schemas import MASTER_SCHEMA, FILTROS_HERRAMIENTAS

# Extractors
from src.extractors.access_reader import read_access_table

# Transformers
from src.transformers.normalizer import (
    normalize_column_names,
    map_to_master_schema,
    clean_string_columns
)
from src.transformers.parsers import parse_master_columns
from src.transformers.deduplicator import (
    generate_hash_id,
    detect_duplicates_within,
    remove_duplicates,
    filter_only_new_records
)

# Loaders
from src.loaders.sqlite_loader import SQLiteLoader

# Utils
from src.utils.logger import setup_logger, MetricsLogger

logger = setup_logger("pipeline_main")
metrics = MetricsLogger(logger)


class FraudPipeline:
    """
    Pipeline completo de consolidación de herramientas de fraude.
    """
    
    def __init__(self, incremental: bool = True):
        """
        Args:
            incremental: Si True, solo carga registros nuevos
        """
        self.incremental = incremental
        self.db_loader = SQLiteLoader(MASTER_DB, MASTER_TABLE)
        
        # Reportes consolidados
        self.all_mappings = []
        self.all_parse_fails = []
        self.all_duplicates = []
        
        logger.info("=" * 80)
        logger.info("INICIO DEL PIPELINE DE CONSOLIDACIÓN")
        logger.info(f"Modo: {'INCREMENTAL' if incremental else 'FULL LOAD'}")
        logger.info("=" * 80)
    
    def process_tool(
        self,
        herramienta: str,
        df_raw: pl.DataFrame,
        apply_filters: bool = True
    ) -> pl.DataFrame:
        """
        Procesa una herramienta completa: normalización, parseo, dedup.
        
        Args:
            herramienta: Nombre de la herramienta
            df_raw: DataFrame crudo
            apply_filters: Si aplicar filtros de negocio
            
        Returns:
            DataFrame procesado y listo para carga
        """
        logger.info(f"\n{'─' * 60}")
        logger.info(f"PROCESANDO: {herramienta}")
        logger.info(f"{'─' * 60}")
        
        metrics.log_extraction(herramienta, len(df_raw), df_raw.shape[1])
        
        # 1. NORMALIZAR COLUMNAS
        df = normalize_column_names(df_raw)
        
        # 2. MAPEAR A ESQUEMA MASTER
        df, mapping_report = map_to_master_schema(df, herramienta)
        self.all_mappings.append(mapping_report)
        
        # 3. APLICAR FILTROS DE NEGOCIO
        if apply_filters and herramienta in FILTROS_HERRAMIENTAS:
            df = self._apply_business_filters(df, herramienta)
        
        # 4. PARSEAR FECHA Y MONTO
        df, parse_fails = parse_master_columns(df, herramienta)
        if len(parse_fails) > 0:
            self.all_parse_fails.append(parse_fails)
        
        # 5. LIMPIAR COLUMNAS STRING
        df = clean_string_columns(df)
        
        # 6. AGREGAR COLUMNA HERRAMIENTA
        df = df.with_columns(pl.lit(herramienta).alias("herramienta"))
        
        # 7. GENERAR HASH PARA DEDUPLICACIÓN
        df = generate_hash_id(df)
        
        # 8. ELIMINAR DUPLICADOS INTERNOS
        duplicados = detect_duplicates_within(df)
        if len(duplicados) > 0:
            self.all_duplicates.append(
                duplicados.with_columns(pl.lit("interno").alias("tipo_duplicado"))
            )
        df = remove_duplicates(df, keep="first")
        
        # 9. SELECCIONAR SOLO COLUMNAS MASTER + hash_id
        master_cols = list(MASTER_SCHEMA.keys())
        df = df.select(master_cols)
        
        metrics.log_transformation(herramienta, len(df_raw), len(df))
        
        return df
    
    def _apply_business_filters(self, df: pl.DataFrame, herramienta: str) -> pl.DataFrame:
        """Aplica filtros de negocio según herramienta."""
        filtros = FILTROS_HERRAMIENTAS[herramienta]
        filas_antes = len(df)
        
        if herramienta == "FRM":
            # Normalizar columnas temporalmente para filtros
            df_temp = df.with_columns([
                pl.col("condicion").cast(pl.Utf8).str.strip_chars().alias("_cond"),
                pl.col("de39 resp de autorizacion").cast(pl.Utf8).str.strip_chars().alias("_de39")
            ])
            
            # Filtrar
            df = df_temp.filter(
                (
                    pl.col("_cond").is_null() |
                    (pl.col("_cond") == "") |
                    (~pl.col("_cond").is_in(filtros["excluir_condicion"]))
                ) &
                (pl.col("_de39") == filtros["solo_de39"])
            )
            
            # Eliminar columnas temporales
            df = df.drop(["_cond", "_de39"])
        
        elif herramienta == "RT_CREDITO":
            # Filtrar por fecha mínima
            fecha_min = pl.lit(filtros["fecha_minima"]).str.to_date()
            df = df.filter(pl.col("fecha") >= fecha_min)
        
        filas_despues = len(df)
        logger.info(
            f"Filtros aplicados: {filas_antes:,} → {filas_despues:,} "
            f"({filas_antes - filas_despues:,} eliminadas)"
        )
        
        return df
    
    def run(self):
        """Ejecuta pipeline completo."""
        ensure_directories()
        
        # INICIALIZAR SQLITE
        with self.db_loader as loader:
            if not loader.table_exists():
                loader.create_table()
                logger.info("Tabla master creada en SQLite")
            
            # Obtener hashes existentes para dedup incremental
            existing_hashes = loader.get_existing_hashes() if self.incremental else []
        
        # ====================================================================
        # EXTRAER Y PROCESAR CADA HERRAMIENTA
        # ====================================================================
        
        # VRM
        logger.info("\n" + "=" * 80)
        logger.info("EXTRAYENDO VRM")
        df_vrm_raw = read_access_table(RUTA_BD_VRM, TABLA_VRM)
        df_vrm = self.process_tool("VRM", df_vrm_raw)
        
        # FRM
        logger.info("\n" + "=" * 80)
        logger.info("EXTRAYENDO FRM")
        df_frm_raw = read_access_table(RUTA_BD_FRM, TABLA_FRM)
        df_frm = self.process_tool("FRM", df_frm_raw, apply_filters=True)
        
        # RT DÉBITO
        logger.info("\n" + "=" * 80)
        logger.info("EXTRAYENDO RT_DEBITO")
        df_rt_d_raw = read_access_table(RUTA_BD_RT_D, TABLA_RT_D)
        df_rt_d = self.process_tool("RT_DEBITO", df_rt_d_raw)
        
        # RT CRÉDITO
        logger.info("\n" + "=" * 80)
        logger.info("EXTRAYENDO RT_CREDITO")
        df_rt_c_raw = read_access_table(RUTA_BD_RT_C, TABLA_RT_C)
        df_rt_c = self.process_tool("RT_CREDITO", df_rt_c_raw, apply_filters=True)
        
        # VCAS
        logger.info("\n" + "=" * 80)
        logger.info("EXTRAYENDO VCAS")
        df_vcas_raw = pl.read_csv(VCAS_CSV, encoding="utf8", infer_schema_length=10000)
        df_vcas = self.process_tool("VCAS", df_vcas_raw)
        
        # ====================================================================
        # CONSOLIDAR
        # ====================================================================
        logger.info("\n" + "=" * 80)
        logger.info("CONSOLIDANDO TODAS LAS HERRAMIENTAS")
        
        master_df = pl.concat([df_vrm, df_frm, df_rt_d, df_rt_c, df_vcas])
        logger.info(f"Total registros consolidados: {len(master_df):,}")
        
        # ====================================================================
        # DEDUPLICACIÓN VS HISTÓRICO (si incremental)
        # ====================================================================
        if self.incremental and len(existing_hashes) > 0:
            logger.info("\n" + "=" * 80)
            logger.info("FILTRANDO DUPLICADOS VS HISTÓRICO")
            
            duplicados_historico = master_df.join(
                pl.DataFrame({"hash_id": existing_hashes}),
                on="hash_id",
                how="semi"
            )
            
            if len(duplicados_historico) > 0:
                self.all_duplicates.append(
                    duplicados_historico
                    .select(["hash_id", "fecha", "monto_usd", "nombre_comercio", "herramienta"])
                    .with_columns(pl.lit("vs_historico").alias("tipo_duplicado"))
                )
            
            master_df = filter_only_new_records(master_df, existing_hashes)
        
        # ====================================================================
        # CARGAR A SQLITE
        # ====================================================================
        logger.info("\n" + "=" * 80)
        logger.info("CARGANDO A SQLITE")
        
        with self.db_loader as loader:
            loader.insert_dataframe(master_df, if_exists="append")
            
            total_registros = loader.get_row_count()
            logger.info(f"Total acumulado en SQLite: {total_registros:,}")
        
        # ====================================================================
        # GUARDAR REPORTES DE DIAGNÓSTICO
        # ====================================================================
        self._save_diagnostics()
        
        logger.info("\n" + "=" * 80)
        logger.info("PIPELINE COMPLETADO EXITOSAMENTE")
        logger.info("=" * 80)
    
    def _save_diagnostics(self):
        """Guarda reportes consolidados de diagnóstico."""
        logger.info("\nGuardando reportes de diagnóstico...")
        
        # 1. Mapping
        if self.all_mappings:
            mapping_df = pl.concat(self.all_mappings)
            mapping_df.write_csv(REPORT_MAPPING)
            logger.info(f"✓ Mapping: {REPORT_MAPPING}")
        
        # 2. Parse fails
        if self.all_parse_fails:
            parse_df = pl.concat(self.all_parse_fails)
            parse_df.write_csv(REPORT_PARSE_FAILS)
            logger.info(f"✓ Parse fails: {REPORT_PARSE_FAILS}")
        
        # 3. Duplicados
        if self.all_duplicates:
            dup_df = pl.concat(self.all_duplicates)
            dup_df.write_csv(REPORT_DUPLICADOS)
            logger.info(f"✓ Duplicados: {REPORT_DUPLICADOS}")


# ============================================================================
# ENTRY POINT
# ============================================================================
if __name__ == "__main__":
    pipeline = FraudPipeline(incremental=True)
    pipeline.run()
