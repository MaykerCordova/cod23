"""
QUERIES SQL ÚTILES PARA POWER BI
================================

Colección de queries optimizadas para crear medidas y visualizaciones
en Power BI conectado a la base SQLite.

Copiar y pegar directamente en:
- Editor de Consultas (Power Query)
- Medidas DAX (adaptando sintaxis)
- Consultas SQL nativas en DirectQuery
"""

# ==============================================================================
# 1. TABLA CALENDARIO (para relacionar con fecha)
# ==============================================================================
TABLA_CALENDARIO = """
-- Crear tabla calendario desde fecha mínima a máxima
WITH RECURSIVE dates(date) AS (
    SELECT MIN(fecha) FROM master_consolidado
    UNION ALL
    SELECT date(date, '+1 day')
    FROM dates
    WHERE date < (SELECT MAX(fecha) FROM master_consolidado)
)
SELECT 
    date as Fecha,
    CAST(strftime('%Y', date) AS INTEGER) as Año,
    CAST(strftime('%m', date) AS INTEGER) as Mes,
    CAST(strftime('%d', date) AS INTEGER) as Dia,
    strftime('%Y-%m', date) as AñoMes,
    CASE CAST(strftime('%w', date) AS INTEGER)
        WHEN 0 THEN 'Domingo'
        WHEN 1 THEN 'Lunes'
        WHEN 2 THEN 'Martes'
        WHEN 3 THEN 'Miércoles'
        WHEN 4 THEN 'Jueves'
        WHEN 5 THEN 'Viernes'
        WHEN 6 THEN 'Sábado'
    END as DiaSemana,
    CASE 
        WHEN CAST(strftime('%w', date) AS INTEGER) IN (0, 6) THEN 'Fin de Semana'
        ELSE 'Día Hábil'
    END as TipoDia
FROM dates
ORDER BY date;
"""

# ==============================================================================
# 2. RESUMEN DIARIO (para gráficos de línea temporal)
# ==============================================================================
RESUMEN_DIARIO = """
SELECT 
    fecha,
    COUNT(*) as CantidadTransacciones,
    SUM(monto_usd) as MontoTotal,
    AVG(monto_usd) as TicketPromedio,
    COUNT(DISTINCT nombre_comercio) as ComerciosUnicos,
    COUNT(DISTINCT bin) as BinsUnicos
FROM master_consolidado
WHERE fecha >= date('now', '-90 days')  -- Últimos 90 días
GROUP BY fecha
ORDER BY fecha;
"""

# ==============================================================================
# 3. RESUMEN POR HERRAMIENTA (para cards/KPIs)
# ==============================================================================
RESUMEN_HERRAMIENTA = """
SELECT 
    herramienta,
    COUNT(*) as TotalRegistros,
    SUM(monto_usd) as MontoAcumulado,
    AVG(monto_usd) as TicketPromedio,
    MIN(fecha) as FechaInicio,
    MAX(fecha) as FechaFin,
    -- Últimos 30 días
    SUM(CASE WHEN fecha >= date('now', '-30 days') THEN 1 ELSE 0 END) as Registros30d,
    SUM(CASE WHEN fecha >= date('now', '-30 days') THEN monto_usd ELSE 0 END) as Monto30d
FROM master_consolidado
GROUP BY herramienta
ORDER BY TotalRegistros DESC;
"""

# ==============================================================================
# 4. TOP COMERCIOS (para ranking dinámico)
# ==============================================================================
TOP_COMERCIOS = """
SELECT 
    nombre_comercio,
    codigo_pais,
    COUNT(*) as Transacciones,
    SUM(monto_usd) as MontoTotal,
    AVG(monto_usd) as TicketPromedio,
    MIN(fecha) as PrimeraTransaccion,
    MAX(fecha) as UltimaTransaccion,
    -- Días activos
    julianday(MAX(fecha)) - julianday(MIN(fecha)) + 1 as DiasActivo,
    -- Frecuencia
    ROUND(
        COUNT(*) * 1.0 / NULLIF(julianday(MAX(fecha)) - julianday(MIN(fecha)) + 1, 0),
        2
    ) as TransaccionesPorDia
FROM master_consolidado
WHERE nombre_comercio IS NOT NULL
GROUP BY nombre_comercio, codigo_pais
HAVING Transacciones >= 10  -- Mínimo 10 transacciones
ORDER BY Transacciones DESC
LIMIT 100;
"""

# ==============================================================================
# 5. EVOLUCIÓN MENSUAL (para gráfico de barras/líneas)
# ==============================================================================
EVOLUCION_MENSUAL = """
SELECT 
    strftime('%Y-%m', fecha) as Mes,
    COUNT(*) as Transacciones,
    SUM(monto_usd) as MontoTotal,
    AVG(monto_usd) as TicketPromedio,
    COUNT(DISTINCT nombre_comercio) as ComerciosActivos,
    -- Variación vs mes anterior (requiere window functions en versiones nuevas de SQLite)
    COUNT(*) - LAG(COUNT(*)) OVER (ORDER BY strftime('%Y-%m', fecha)) as DeltaTransacciones
FROM master_consolidado
WHERE fecha >= date('now', 'start of month', '-12 months')  -- Últimos 12 meses
GROUP BY Mes
ORDER BY Mes;
"""

# ==============================================================================
# 6. DISTRIBUCIÓN POR ENTRY MODE (para pie chart)
# ==============================================================================
DISTRIBUCION_ENTRY_MODE = """
SELECT 
    COALESCE(entry_mode, 'SIN DATO') as EntryMode,
    COUNT(*) as Cantidad,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM master_consolidado), 2) as Porcentaje,
    SUM(monto_usd) as MontoTotal
FROM master_consolidado
GROUP BY entry_mode
ORDER BY Cantidad DESC;
"""

# ==============================================================================
# 7. ANÁLISIS POR PAÍS (para mapa geográfico)
# ==============================================================================
ANALISIS_PAISES = """
SELECT 
    codigo_pais as CodigoPais,
    COUNT(*) as Transacciones,
    SUM(monto_usd) as MontoTotal,
    AVG(monto_usd) as TicketPromedio,
    COUNT(DISTINCT nombre_comercio) as Comercios
FROM master_consolidado
WHERE codigo_pais IS NOT NULL
GROUP BY codigo_pais
ORDER BY Transacciones DESC;
"""

# ==============================================================================
# 8. DETECCIÓN DE OUTLIERS (para scatter plot)
# ==============================================================================
OUTLIERS_MONTO = """
WITH stats AS (
    SELECT 
        AVG(monto_usd) as media,
        -- Aproximación de desviación estándar
        SQRT(AVG((monto_usd - (SELECT AVG(monto_usd) FROM master_consolidado)) * 
                 (monto_usd - (SELECT AVG(monto_usd) FROM master_consolidado)))) as std_dev
    FROM master_consolidado
)
SELECT 
    m.fecha,
    m.nombre_comercio,
    m.monto_usd,
    m.herramienta,
    -- Z-score
    ROUND((m.monto_usd - s.media) / NULLIF(s.std_dev, 0), 2) as ZScore,
    CASE 
        WHEN ABS((m.monto_usd - s.media) / NULLIF(s.std_dev, 0)) > 3 THEN 'Outlier Extremo'
        WHEN ABS((m.monto_usd - s.media) / NULLIF(s.std_dev, 0)) > 2 THEN 'Outlier'
        ELSE 'Normal'
    END as Categoria
FROM master_consolidado m
CROSS JOIN stats s
WHERE m.monto_usd IS NOT NULL
ORDER BY ABS((m.monto_usd - s.media) / NULLIF(s.std_dev, 0)) DESC
LIMIT 500;
"""

# ==============================================================================
# 9. RECURRENCIA DE COMERCIOS (para análisis de comportamiento)
# ==============================================================================
RECURRENCIA_COMERCIOS = """
SELECT 
    nombre_comercio,
    COUNT(*) as TotalTransacciones,
    COUNT(DISTINCT strftime('%Y-%m', fecha)) as MesesActivo,
    -- Primera y última transacción
    MIN(fecha) as PrimeraVez,
    MAX(fecha) as UltimaVez,
    -- Días desde última transacción
    julianday('now') - julianday(MAX(fecha)) as DiasSinActividad,
    -- Categoría de recurrencia
    CASE 
        WHEN COUNT(DISTINCT strftime('%Y-%m', fecha)) >= 6 THEN 'Alta Recurrencia'
        WHEN COUNT(DISTINCT strftime('%Y-%m', fecha)) >= 3 THEN 'Recurrencia Media'
        ELSE 'Baja Recurrencia'
    END as CategoriaRecurrencia
FROM master_consolidado
WHERE nombre_comercio IS NOT NULL
GROUP BY nombre_comercio
HAVING TotalTransacciones >= 5
ORDER BY MesesActivo DESC, TotalTransacciones DESC;
"""

# ==============================================================================
# 10. COHORT ANALYSIS (análisis por cohorte de fecha de primera transacción)
# ==============================================================================
COHORT_ANALYSIS = """
WITH primera_transaccion AS (
    SELECT 
        nombre_comercio,
        MIN(fecha) as fecha_primera
    FROM master_consolidado
    WHERE nombre_comercio IS NOT NULL
    GROUP BY nombre_comercio
),
transacciones_con_cohorte AS (
    SELECT 
        m.*,
        strftime('%Y-%m', pt.fecha_primera) as cohorte,
        -- Meses desde primera transacción
        (strftime('%Y', m.fecha) - strftime('%Y', pt.fecha_primera)) * 12 +
        (strftime('%m', m.fecha) - strftime('%m', pt.fecha_primera)) as mes_desde_inicio
    FROM master_consolidado m
    INNER JOIN primera_transaccion pt ON m.nombre_comercio = pt.nombre_comercio
)
SELECT 
    cohorte,
    mes_desde_inicio,
    COUNT(DISTINCT nombre_comercio) as ComerciosActivos,
    COUNT(*) as Transacciones,
    SUM(monto_usd) as MontoTotal
FROM transacciones_con_cohorte
WHERE cohorte >= '2024-01'  -- Desde enero 2024
GROUP BY cohorte, mes_desde_inicio
ORDER BY cohorte, mes_desde_inicio;
"""

# ==============================================================================
# TIPS PARA POWER BI
# ==============================================================================
"""
CONEXIÓN A SQLITE EN POWER BI:
-------------------------------
1. Obtener datos → Base de datos → Base de datos ODBC
2. DSN: Crear DSN SQLite (requiere driver SQLite ODBC)
3. Ruta: data/historico/master.db

MODO DIRECTQUERY VS IMPORT:
---------------------------
- DirectQuery: Datos siempre actualizados, pero más lento
- Import: Más rápido, pero requiere refrescar manualmente

MEDIDAS DAX ÚTILES:
-------------------
Total Transacciones = COUNTROWS(master_consolidado)

Monto Total = SUM(master_consolidado[monto_usd])

Ticket Promedio = AVERAGE(master_consolidado[monto_usd])

Transacciones Mes Actual = 
CALCULATE(
    COUNTROWS(master_consolidado),
    DATESMTD(master_consolidado[fecha])
)

Variación vs Mes Anterior = 
VAR MesActual = [Total Transacciones]
VAR MesAnterior = 
    CALCULATE(
        [Total Transacciones],
        DATEADD(master_consolidado[fecha], -1, MONTH)
    )
RETURN
    DIVIDE(MesActual - MesAnterior, MesAnterior)

Top N Dinámico (usar parámetro):
RANKX(
    ALL(master_consolidado[nombre_comercio]),
    [Total Transacciones]
) <= [Parámetro TopN]
"""
