"""
Utilidades para gestión del histórico SQLite.
Reset, backup, estadísticas, eliminación de duplicados, etc.
"""
import sqlite3
import shutil
from datetime import datetime
from pathlib import Path

from config.paths import MASTER_DB, MASTER_TABLE, HISTORICO_DIR
from src.loaders.sqlite_loader import SQLiteLoader


def reset_database():
    """
    Elimina completamente la base SQLite.
    Útil para hacer carga completa desde cero.
    """
    print("\n⚠️  ADVERTENCIA: Esta acción eliminará TODOS los datos históricos")
    confirm = input("¿Confirmar reset? (escribe 'CONFIRMAR'): ")
    
    if confirm != "CONFIRMAR":
        print("❌ Operación cancelada")
        return
    
    if MASTER_DB.exists():
        MASTER_DB.unlink()
        print(f"✓ Base de datos eliminada: {MASTER_DB}")
    else:
        print(f"ℹ️  No existe: {MASTER_DB}")
    
    print("\n▶️  Ejecuta main.py para recrear la base desde cero")


def backup_database():
    """Crea backup de la base SQLite."""
    
    if not MASTER_DB.exists():
        print("❌ No existe base de datos para hacer backup")
        return
    
    backup_dir = HISTORICO_DIR / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = backup_dir / f"master_backup_{timestamp}.db"
    
    shutil.copy2(MASTER_DB, backup_path)
    
    # Tamaño del archivo
    size_mb = backup_path.stat().st_size / (1024 * 1024)
    
    print(f"✓ Backup creado: {backup_path}")
    print(f"  Tamaño: {size_mb:.2f} MB")


def estadisticas_db():
    """Muestra estadísticas detalladas de la base."""
    
    if not MASTER_DB.exists():
        print("❌ No existe base de datos")
        return
    
    print("\n" + "=" * 80)
    print("ESTADÍSTICAS DE BASE DE DATOS")
    print("=" * 80)
    
    # Tamaño archivo
    size_mb = MASTER_DB.stat().st_size / (1024 * 1024)
    print(f"\n📁 Archivo: {MASTER_DB}")
    print(f"   Tamaño: {size_mb:.2f} MB")
    
    with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
        # Total registros
        total = loader.get_row_count()
        print(f"\n📊 Total registros: {total:,}")
        
        # Por herramienta
        print("\n" + "-" * 60)
        print("DISTRIBUCIÓN POR HERRAMIENTA")
        print("-" * 60)
        
        df = loader.query(f"""
            SELECT 
                herramienta,
                COUNT(*) as cantidad,
                MIN(fecha) as desde,
                MAX(fecha) as hasta,
                MIN(fecha_carga) as primera_carga,
                MAX(fecha_carga) as ultima_carga
            FROM {MASTER_TABLE}
            GROUP BY herramienta
            ORDER BY cantidad DESC
        """)
        print(df)
        
        # Índices
        print("\n" + "-" * 60)
        print("ÍNDICES CREADOS")
        print("-" * 60)
        
        df_idx = loader.query("""
            SELECT name, tbl_name, sql
            FROM sqlite_master
            WHERE type = 'index' AND tbl_name = 'master_consolidado'
        """)
        print(df_idx)


def detectar_duplicados_post_carga():
    """
    Detecta duplicados que pudieron colarse después de la carga.
    Útil para diagnóstico.
    """
    print("\n" + "=" * 80)
    print("DETECCIÓN DE DUPLICADOS EN BASE HISTÓRICA")
    print("=" * 80)
    
    with SQLiteLoader(MASTER_DB, MASTER_TABLE) as loader:
        
        # Buscar duplicados por hash_id
        df_dups = loader.query(f"""
            SELECT 
                hash_id,
                COUNT(*) as veces,
                GROUP_CONCAT(DISTINCT herramienta) as herramientas,
                MIN(fecha) as fecha_min,
                MAX(fecha) as fecha_max
            FROM {MASTER_TABLE}
            GROUP BY hash_id
            HAVING COUNT(*) > 1
            ORDER BY veces DESC
            LIMIT 100
        """)
        
        if len(df_dups) == 0:
            print("\n✓ No se encontraron duplicados")
        else:
            print(f"\n⚠️  Encontrados {len(df_dups)} hash_id duplicados")
            print(df_dups)
            
            # Exportar reporte
            reporte_path = HISTORICO_DIR / "duplicados_post_carga.csv"
            df_dups.write_csv(reporte_path)
            print(f"\n📄 Reporte guardado: {reporte_path}")


def eliminar_duplicados():
    """
    Elimina duplicados del histórico manteniendo el registro más reciente.
    """
    print("\n⚠️  Esta operación eliminará registros duplicados")
    confirm = input("¿Confirmar eliminación? (escribe 'SI'): ")
    
    if confirm != "SI":
        print("❌ Operación cancelada")
        return
    
    conn = sqlite3.connect(MASTER_DB)
    
    # Contar duplicados antes
    cursor = conn.cursor()
    cursor.execute(f"""
        SELECT COUNT(*) 
        FROM {MASTER_TABLE} t1
        WHERE EXISTS (
            SELECT 1 FROM {MASTER_TABLE} t2 
            WHERE t2.hash_id = t1.hash_id 
            AND t2.rowid > t1.rowid
        )
    """)
    duplicados_antes = cursor.fetchone()[0]
    
    if duplicados_antes == 0:
        print("✓ No hay duplicados que eliminar")
        conn.close()
        return
    
    print(f"Duplicados detectados: {duplicados_antes:,}")
    
    # Eliminar (mantener solo el de mayor rowid = más reciente)
    cursor.execute(f"""
        DELETE FROM {MASTER_TABLE}
        WHERE rowid NOT IN (
            SELECT MAX(rowid)
            FROM {MASTER_TABLE}
            GROUP BY hash_id
        )
    """)
    
    conn.commit()
    
    print(f"✓ Eliminados {cursor.rowcount:,} registros duplicados")
    
    # Vacuum para recuperar espacio
    print("\nOptimizando base de datos (VACUUM)...")
    conn.execute("VACUUM")
    
    conn.close()
    
    print("✓ Base optimizada")


def menu_principal():
    """Menú interactivo de utilidades."""
    
    while True:
        print("\n" + "=" * 80)
        print("UTILIDADES - GESTIÓN DE HISTÓRICO")
        print("=" * 80)
        print("\n1. Estadísticas de la base")
        print("2. Crear backup")
        print("3. Detectar duplicados")
        print("4. Eliminar duplicados")
        print("5. RESET completo (elimina todo)")
        print("0. Salir")
        
        opcion = input("\nSelecciona opción: ").strip()
        
        if opcion == "1":
            estadisticas_db()
        elif opcion == "2":
            backup_database()
        elif opcion == "3":
            detectar_duplicados_post_carga()
        elif opcion == "4":
            eliminar_duplicados()
        elif opcion == "5":
            reset_database()
        elif opcion == "0":
            print("👋 Saliendo...")
            break
        else:
            print("❌ Opción inválida")


if __name__ == "__main__":
    menu_principal()
