# 🛡️ Fraud Analyzer — Scotiabank Peru

App Streamlit para análisis de fraude transaccional por comercio,
detección de Punto de Compromiso (POC), modelado y generación de reglas.

## Instalación

```bash
pip install -r requirements.txt
```

## Cómo correr

```bash
streamlit run app.py
```

Abre automáticamente en: http://localhost:8501

---

## Flujo de uso

1. **Sidebar → Datos**
   - Activa "Usar datos sintéticos" para demo inmediato
   - O sube un CSV/Excel exportado del Monitor

2. **Sidebar → Mapeo de columnas**
   - Ajusta los nombres de columna según tu export
   - Columnas clave: fecha, monto, comercio, bin, indicador_fraude, codigo_respuesta

3. **Sidebar → Parámetros**
   - Ajusta umbrales de fraud rate, scores y ventana velocity

---

## Secciones

### 🏪 Comercios
- Ranking por score de riesgo compuesto (fraud rate + EFL + severidad)
- Scatter fraud rate vs EFL con detección de POC
- Evolución mensual por comercio seleccionado

### 💳 BINs & POC
- Detección automática de Punto de Compromiso
- Scatter tarjetas afectadas vs fraud rate
- Top BINs con velocity bursts

### 🤖 Modelo & Score
- Teacher model (LightGBM/RandomForest) + Regresión Logística
- Curva ROC comparativa
- Distribución de scores por clase
- **Fórmula lista para implementar en el motor**
- Árbol destilado (reglas if/then)

### ⚙️ Reglas Candidatas
- Generación automática de reglas por tipo:
  - FRAUD_RATE: comercios sobre umbral
  - PUNTO_COMPROMISO: BINs comprometidos
  - VELOCITY: ráfagas por BIN
  - N7_ELEVADO: riesgo CNP
  - SCORE_MODELO: umbral de probabilidad
- Exportar reglas como CSV
- Exportar transacciones con score

---

## Lógica de etiquetado (target)

| Indicador | Significado | Uso en modelo |
|-----------|------------|---------------|
| F | Fraude confirmado | ✅ Positivo (train) |
| G | Buena confirmada | ✅ Negativo (train) |
| D | Descarte analista | ⚠️ Negativo peso 0.5 |
| N | Sin revisar | 🔲 Solo inferencia |
| P | Pendiente | ❌ Excluido |

## Códigos de respuesta críticos

| Código | Significado | Uso |
|--------|------------|-----|
| N7 | CVV2 no coincide | Feature fuerte CNP fraud |
| 04 | Tarjeta robada | Feature crítica |
| 14 | Tarjeta inválida | Posible BIN testing |
| 51 | Sin fondos | Feature comportamiento |
| 59/53/69 | Regla interna | Ya en radar del motor |
| 00 | Aprobada | Baseline |
